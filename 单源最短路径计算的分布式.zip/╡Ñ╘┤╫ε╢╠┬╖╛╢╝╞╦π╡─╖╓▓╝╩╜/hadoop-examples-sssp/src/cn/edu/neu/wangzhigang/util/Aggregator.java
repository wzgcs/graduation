package cn.edu.neu.wangzhigang.util;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
public class Aggregator {
	
	public static enum VertexCounter {
		ACTIVE, UNACTIVE, TOTAL, SEND, Receive
	}
}
