package cn.edu.neu.wangzhigang.sssp;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import cn.edu.neu.wangzhigang.util.Vertex;
import cn.edu.neu.wangzhigang.util.VertexState;

/**
 * SSSPCombiner
 * The function is similar with {@link SSSPReducer}.
 * It only process the vertex used as messages and it will not update the {@link VertexState}.
 * 
 * Note: {@link SSSPCombiner} will not count the number of vertices whose {@link VertexState} is {@link VertexState.ACTIVE}.
 * 
 * @author Zhigang Wang
 * @version 0.1
 */

public class SSSPCombiner extends Reducer<IntWritable, Text, IntWritable, Text>{
	
	@Override
	public void reduce(IntWritable key, Iterable<Text> values, Context context) 
			throws IOException,InterruptedException {
		Vertex vertex = new Vertex(key.get());
		vertex.updateVertexValue(Integer.MAX_VALUE);
		vertex.updateVertexState(VertexState.ACTIVE);
		int vertexValue = Integer.MAX_VALUE;
		boolean sendFlag = false;
		
		for (Text value : values) {
			Vertex tmpVertex = new Vertex(key.get(), value.toString());
			if (tmpVertex.hasEdges()) {
				vertexValue = tmpVertex.getVertexValue();
				context.write(key, new Text(tmpVertex.toString()));
				continue;
			}
			
			if (tmpVertex.getVertexValue() < vertex.getVertexValue()) {
				vertex.updateVertexValue(tmpVertex.getVertexValue());
				sendFlag = true;
			}
		}
		
		if (sendFlag && vertex.getVertexValue() < vertexValue) {
			context.write(key, new Text(vertex.toString()));
		}
	}
}
