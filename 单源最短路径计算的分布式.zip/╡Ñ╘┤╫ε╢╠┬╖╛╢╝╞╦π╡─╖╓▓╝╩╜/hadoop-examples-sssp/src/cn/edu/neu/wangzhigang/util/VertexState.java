package cn.edu.neu.wangzhigang.util;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
public class VertexState {
	public static int ACTIVE = 1;
	public static int UNACTIVE = 0;
}