package cn.edu.neu.wangzhigang.util;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
public class Edge {
	
	private int dstVertexId;
	private int weight;
	
	public Edge(int dstVertexId, int weight) {
		this.dstVertexId = dstVertexId;
		this.weight = weight;
	}
	
	public int getDstVertexId() {
		return this.dstVertexId;
	}
	
	public int getWeight() {
		return this.weight;
	}

}
