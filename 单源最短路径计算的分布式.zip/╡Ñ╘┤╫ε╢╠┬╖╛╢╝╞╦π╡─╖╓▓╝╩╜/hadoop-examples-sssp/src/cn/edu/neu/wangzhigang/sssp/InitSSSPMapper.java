package cn.edu.neu.wangzhigang.sssp;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import cn.edu.neu.wangzhigang.util.Edge;
import cn.edu.neu.wangzhigang.util.Util;
import cn.edu.neu.wangzhigang.util.Vertex;
import cn.edu.neu.wangzhigang.util.VertexState;

/**
 * InitSSSPMapper
 * This only is used for the first iterator.
 * The function is to transfer the format of graph data and process the source vertex.
 * The input <key, value> format is, <key> = [vertexId:vertexValue] and <value> = [dstId:weight:distId:weight...].
 * The output <key, value> format is, <key> = [vertexId] and <value> = [vertexValue:vertexState:dstId:weight...].
 * Certainly, the output <key, value> used as messages or the vertex has not outgoing edges is special, 
 * <value> = [vertexValue:vertexState].
 * 
 * For the output <key, value> used as messages, the {@link VertextState} is {@link VertexState.ACTIVE}.
 * While, for other output <key, value>, it is {@link VertexState.UNACTIVE}.
 * 
 * @author Zhigang Wang
 * @version 0.1
 */

public class InitSSSPMapper extends Mapper<Text, Text, IntWritable, Text> {
	
	private int sourceVertexId = 0;
	
	@Override
	public void setup(Context context){
		sourceVertexId = Integer.valueOf(context.getConfiguration().get(Util.SOURCE_VERTEX_ID));
	}
	
	@Override
	public void map(Text key, Text value,Context context) 
			throws IOException, InterruptedException {
		Vertex vertex = new Vertex(key.toString(), value.toString(), VertexState.ACTIVE);
		if (vertex.getVertexId() == sourceVertexId) {
			vertex.updateVertexValue(0);
			for (Edge edge : vertex.getEdges()) {
				Vertex tmpVertex = new Vertex(edge.getDstVertexId());
				tmpVertex.updateVertexValue(vertex.getVertexValue() + edge.getWeight());
				tmpVertex.updateVertexState(VertexState.ACTIVE);
				context.write(new IntWritable(tmpVertex.getVertexId()), new Text(tmpVertex.toString()));
			}
		}
		
		vertex.updateVertexState(VertexState.UNACTIVE);
		context.write(new IntWritable(vertex.getVertexId()), new Text(vertex.toString()));
	}
	
	
}
