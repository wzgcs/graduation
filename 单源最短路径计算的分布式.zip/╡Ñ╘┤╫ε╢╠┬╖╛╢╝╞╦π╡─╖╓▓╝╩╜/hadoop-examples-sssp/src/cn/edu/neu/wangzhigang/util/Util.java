package cn.edu.neu.wangzhigang.util;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
public class Util {
	public static String FILE_FLAG = "-";
	public static String SOURCE_VERTEX_ID = "source.vertex.id";
	public static String VERTEX_EDGE_FLAG = "\t";
	public static String VERTEX_FLAG = ":";
	public static String EDGE_FLAG = ":";
	
	public static String getJobName (int currentIterator) {
		return "Hadoop-SSSP-Job-" + currentIterator;
	}
}
