package cn.edu.neu.wangzhigang.sssp;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.mapreduce.Reducer;

import cn.edu.neu.wangzhigang.util.Vertex;
import cn.edu.neu.wangzhigang.util.VertexState;
import cn.edu.neu.wangzhigang.util.Aggregator;

/**
 * SSSPReducer
 * The function is to receive map's output, update the vertex's vertexValue and {@link VertexState}, and then save the vertex.
 * The input <key, value> format is, <key> = [vertexId] and <value> = [vertexValue:vertexState:dstId:weight...],
 * or <value> = [vertexValue:vertexState], the latter only for messages or the vertex which has not outgoing edges.
 * 
 * The output <key, value> format is, <key> = [vertexId] and <value> = [vertexValue:vertexState:dstId:weight...],
 * or <value> = [vertexValue:vertexState], the latter only for the vertex which has not outgoing edges.
 * 
 * If the vertex's vertexValue is updated, then the {@link VertextState} is {@link VertexState.ACTIVE},
 * else is {@link VertexState.UNACTIVE}, that means the vertex will not send messages for the next iterator.
 * If the vertex has not outgoing edges, then it must be {@link VertexState.UNACTIVE}.
 * 
 * Note: {@link SSSPReducer} will count the number of vertices whose {@link VertexState} is {@link VertexState.ACTIVE} before
 * it. The {@link Counter} will be read by {@link SSSPDriver} after the job is finished. If the {@link Counter} is zero, then
 * the next iterator will be startup and the jobs will quit advancely.
 * 
 * @author Zhigang Wang
 * @version 0.1
 */

public class SSSPReducer extends Reducer<IntWritable, Text, IntWritable, Text>{
	
	private static Counter ActiveCounter = null;
	private static Counter ReceiveCounter = null;
	
	@Override
	public void setup(Context context) {
		ActiveCounter = context.getCounter(Aggregator.VertexCounter.ACTIVE);
		ReceiveCounter = context.getCounter(Aggregator.VertexCounter.Receive);
	}
	
	@Override
	public void reduce(IntWritable key, Iterable<Text> values, Context context) 
			throws IOException,InterruptedException {
		Vertex vertex = new Vertex(key.get());
		vertex.updateVertexValue(Integer.MAX_VALUE);
		vertex.updateVertexState(VertexState.UNACTIVE);
		
		for (Text value : values) {
			ReceiveCounter.increment(1);
			Vertex tmpVertex = new Vertex(key.get(), value.toString());
			if (tmpVertex.hasEdges()) {
				vertex.setEdges(tmpVertex.getEdges());
				if (tmpVertex.getVertexValue() < vertex.getVertexValue()) {
					vertex.updateVertexValue(tmpVertex.getVertexValue());
					vertex.updateVertexState(VertexState.UNACTIVE);
				}
				continue;
			}
			
			if (tmpVertex.getVertexValue() < vertex.getVertexValue()) {
				vertex.updateVertexValue(tmpVertex.getVertexValue());
				vertex.updateVertexState(VertexState.ACTIVE);
			}
		}
		
		if (!vertex.hasEdges()) {
			vertex.updateVertexState(VertexState.UNACTIVE);
		} else if (vertex.isActive()) {
			ActiveCounter.increment(1);
		}
		
		context.write(key, new Text(vertex.toString()));
	}
}
