package cn.edu.neu.wangzhigang.driver;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import cn.edu.neu.wangzhigang.sssp.*;
import cn.edu.neu.wangzhigang.util.KVInputFormat;
import cn.edu.neu.wangzhigang.util.InitKVInputFormat;
import cn.edu.neu.wangzhigang.util.Util;
import cn.edu.neu.wangzhigang.util.Aggregator;

/**
 * SSSPDriver
 * The class is used to driver the sssp problem and register the {@link InitSSSPMapper} {@link SSSPMapper} and {@link SSSPReducer}.
 * It manages the sequence of Hadoop jobs and the input-output directory.
 * 
 * @author Zhigang Wang
 * @version 0.1
 */

public class SSSPDriver {
	
	private static int MaxIterator = 1;
	private static int CurrentIterator = 0;
	private static int InitIterator = 0;
	private static int ReduceTask = 1;
	private static boolean StartCombiner = false;
	private static String InputPath;
	private static String SourceVertexID;
	private static long StartTime = 0L;
	private static long EndTime = 0L;
	private static double[] Time;
	private static String[] Args;
	private static long[] ActiveCounter;
	private static long[] ReceiveCounter;
	
	public static void main(String[] args) throws Exception{
		if (args.length < 5) {
			System.out.println("Usage: <MaxIterator> <ReduceTask> <SetCombiner> <InputPath> <SourceVertexID>");
			System.exit(-1);
		} else {
			initialize(args);
		}
		

		long startTime = 0L, endTime = 0L;
		startTime = System.currentTimeMillis();
		
		do {
			Job job = getJob();
			job.waitForCompletion(true);
			
			Counters counters = job.getCounters();
			ActiveCounter[CurrentIterator] = counters.findCounter(Aggregator.VertexCounter.ACTIVE).getValue();
			ReceiveCounter[CurrentIterator] = counters.findCounter(Aggregator.VertexCounter.Receive).getValue();
			endTime = System.currentTimeMillis();
			recordTime(startTime, endTime);
			startTime = System.currentTimeMillis();
			
			if (ActiveCounter[CurrentIterator] <= 0) {
				CurrentIterator ++;
				break;
			} else {
				CurrentIterator ++;
			}
		} while (CurrentIterator < MaxIterator);
		
		for (int i = 0; i <= CurrentIterator; i++) {
			String outputDir = InputPath + Util.FILE_FLAG + Integer.toString(i);
			cleanOutputDirectory(outputDir);
		}
		
		EndTime = System.currentTimeMillis();
		recordTime(StartTime, EndTime);
		displayStatisticsData();
	}
	
	private static void initialize(String[] args) {
		MaxIterator = Integer.valueOf(args[0]);
		ReduceTask = Integer.valueOf(args[1]);
		StartCombiner = Boolean.valueOf(args[2]);
		InputPath = args[3];
		SourceVertexID = args[4];
		StartTime = System.currentTimeMillis();
		Time = new double[MaxIterator + 1];
		Args = args;;
		ActiveCounter = new long[MaxIterator];
		ReceiveCounter = new long[MaxIterator];
	}
	
	private static boolean cleanOutputDirectory(String outputDir) {
		Configuration conf = new Configuration();
		try {
			FileSystem fs=FileSystem.get(URI.create(outputDir),conf);
			Path path = new Path(outputDir);
			if (fs.exists(path)) {
				fs.delete(path, true);
			}
			
			return true;
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return false;
		}
		
	}
	
	private static String getInputPath() {
		if (CurrentIterator == InitIterator) {
			return InputPath;
		} else {
			return InputPath + Util.FILE_FLAG + Integer.toString((CurrentIterator - 1));
		}
	}
	
	private static String getOutputPath() {
		String outputDir = InputPath + Util.FILE_FLAG + Integer.toString(CurrentIterator);
		if (cleanOutputDirectory(outputDir)) {
			return outputDir;
		} else {
			// TODO Do nothing.
			return outputDir;
		}
	}
	
	private static Job getJob() {
		Configuration conf = new Configuration();
		conf.set(Util.SOURCE_VERTEX_ID, SourceVertexID);

		try {
			Job job = new Job(conf, Util.getJobName(CurrentIterator));
			
			job.setJarByClass(SSSPDriver.class);
			if (CurrentIterator == InitIterator) {
				job.setMapperClass(InitSSSPMapper.class);
				job.setInputFormatClass(InitKVInputFormat.class);
			} else {
				job.setMapperClass(SSSPMapper.class);
				if (StartCombiner) {
					job.setCombinerClass(SSSPCombiner.class);
				}
				job.setInputFormatClass(KVInputFormat.class);
			}
			job.setOutputKeyClass(IntWritable.class);
			job.setOutputValueClass(Text.class);
			job.setReducerClass(SSSPReducer.class);
			job.setNumReduceTasks(ReduceTask);
			
			String inputPath = getInputPath();
			String outputPath = getOutputPath();
			FileInputFormat.addInputPath(job, new Path(inputPath));
			FileOutputFormat.setOutputPath(job, new Path(outputPath));
			return job;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}	
	}
	
	private static void recordTime(long startTime, long endTime) {
		double costTime = (endTime - startTime) / 1000.0;
		Time[CurrentIterator] = costTime;
	}
	
	private static void displayStatisticsData() {
		StringBuffer sb = new StringBuffer("=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=");
        sb.append("\n    All Jobs has been completed successfully!");
        sb.append("\n=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=");
        sb.append("\n              STATISTICS DATA");
        sb.append("\nMaxIterator:  " + MaxIterator);
        sb.append("\nAllIterator:  " + CurrentIterator);
        sb.append("\nAllCostTime:  " + Time[CurrentIterator] + " seconds");
        
        sb.append("\nDetailTime :");
        for (int index = 0; index < CurrentIterator; index++) {
        	sb.append("\n              iterator[" + index + "]  ");
        	sb.append(Time[index]);
        	sb.append(" seconds");
        }
        
        sb.append("\nActiveCounter:");
        for (int index = 0; index < CurrentIterator; index++) {
        	sb.append("\n              iterator[" + index + "]  ");
        	sb.append(ActiveCounter[index]);
        }
        
        sb.append("\nReceiveCounter:");
        for (int index = 0; index < CurrentIterator; index++) {
        	sb.append("\n              iterator[" + index + "]  ");
        	sb.append(ReceiveCounter[index]);
        }
        
        sb.append("\nOther Information:");
        sb.append("\n              [JVM Agrs Type]   <MaxIterator> <ReduceTask> <SetCombiner> <InputPath> <SourceVertexID>");
        sb.append("\n              [JVM Args Value]");
        for (int index = 0; index < Args.length; index++) {
        	sb.append("  ");
        	sb.append(Args[index]);
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		sb.append("\n=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=");
		sb.append("\nRecord Time: " + sdf.format(new Date()));
		sb.append("\nAuthor: Zhigang Wang");
		System.out.println(sb.toString());
		
		try {
			File dir = new File("/tmp/hadoop-job-history");
			if (!dir.exists()) {
				dir.mkdirs();
			}
			
			File file = new File(dir, "job-" + InputPath);
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(sb.toString());
			bw.close();
			fw.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
