package cn.edu.neu.wangzhigang.util;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
import java.util.Vector;

/**
 * One record content: Vertex<cnode>\t</conde>Others.
 * For the InitIterator, [Vertex] = vertexId:vertexValue
 *                       [Others] = dstVertexId:edgeWeight:dstVertexId:edgeWeight......
 * For the otherIterator, [Vertex] = vertexId
 *                        [Others] = vertexValue:vertexState:dstVertexId:edgeWeight:dstVertexId:edgeWeight......
 * Now, we define the split flag is ":".
 * {@link VertexState}, the state of one vertex is divided into two kinds: ACTIVE and UNACTIVE.
 * {@link Edge}, [Edge] = dstVertexId:edgeWeight.
 * 
 * @author Zhigang Wang
 * @version 0.1
 */

public class Vertex {
	
	private int vertexId = 0;
	private int vertexValue = 0;
	private int vertexState = VertexState.UNACTIVE;
	private Vector<Edge> edges = new Vector<Edge>();
	
	public Vertex(String vertexData, String others, int vertexState) {
		char vertex[] = vertexData.toCharArray();
        int length = vertex.length;
        int begin = 0;
        int end = 0;
        
        do {
            if(end >= length)
                break;
            if(vertex[end] == ':') {
                this.vertexId = Integer.valueOf(new String(vertex, begin, end - begin));
                begin = end + 1;
                this.vertexValue = Integer.valueOf(new String(vertex, begin, length - begin));
                break;
            }
            end++;
        } while(true);
		
		this.vertexState = vertexState;
		
		
		char edges[] = others.toCharArray();
		int dstId = 0, weight = 0;
        length = edges.length;
        begin = 0;
        end = 0;

        for(end = 0; end < length; end++) {
            if(edges[end] != ':') {
                continue;
            }
            dstId = Integer.valueOf(new String(edges, begin, end - begin));
            begin = ++end;
            do {
                if(end >= length) {
                    break;
                }
                if(edges[end] == ':') {
                    weight = Integer.valueOf(new String(edges, begin, end - begin));
                    this.edges.add(new Edge(dstId, weight));
                    begin = end + 1;
                    break;
                }
                end++;
            } while(true);
        }
        
        if (end >= length && length != 0) {
        	weight = Integer.valueOf(new String(edges, begin, length - begin));
            this.edges.add(new Edge(dstId, weight));
        }
	}
	
	public Vertex(int vertexId, String others) {
		this.vertexId = vertexId;
		
		char edges[] = others.toCharArray();
		int dstId = 0, weight = 0;
        int length = edges.length;
        int begin = 0;
        int end = 0;
        int splitNumber = 0;

        for(end = 0; end < length; end++) {
            if(edges[end] != ':') {
                continue;
            }
            dstId = Integer.valueOf(new String(edges, begin, end - begin));
            begin = ++end;
            do {
                if(end >= length) {
                    break;
                }
                if(edges[end] == ':') {
                    weight = Integer.valueOf(new String(edges, begin, end - begin));
                    if (++splitNumber == 1) {
                    	this.vertexValue = dstId;
                    	this.vertexState = weight;
                    } else {
                    	this.edges.add(new Edge(dstId, weight));
                    }
                    begin = end + 1;
                    break;
                }
                end++;
            } while(true);
        }
        
        weight = Integer.valueOf(new String(edges, begin, length - begin));
        if (splitNumber == 0) { 	
        	this.vertexValue = dstId;
        	this.vertexState = weight;
        } else {
        	this.edges.add(new Edge(dstId, weight));
        }
	}
	
	public Vertex(int vertexId) {
		this.vertexId = vertexId;
	}
	
	public int getVertexId() {
		return this.vertexId;
	}
	
	public void updateVertexValue(int vertexValue) {
		this.vertexValue = vertexValue;
	}
	
	public int getVertexValue() {
		return this.vertexValue;
	}
	
	public void updateVertexState(int vertexState) {
		this.vertexState = vertexState;
	}
	
	public boolean isActive() {
		return this.vertexState == VertexState.ACTIVE;
	}
	
	public void setEdges(Vector<Edge> edges) {
		this.edges = edges;
	}
	
	public Vector<Edge> getEdges() {
		return this.edges;
	}
	
	public boolean hasEdges() {
		return this.edges.size() > 0;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer(Integer.toString(this.vertexValue));
		sb.append(Util.EDGE_FLAG);sb.append(this.vertexState);
		for (Edge edge : this.edges) {
			sb.append(Util.EDGE_FLAG);sb.append(edge.getDstVertexId());
			sb.append(Util.EDGE_FLAG);sb.append(edge.getWeight());
		}
		return sb.toString();
	}
}
