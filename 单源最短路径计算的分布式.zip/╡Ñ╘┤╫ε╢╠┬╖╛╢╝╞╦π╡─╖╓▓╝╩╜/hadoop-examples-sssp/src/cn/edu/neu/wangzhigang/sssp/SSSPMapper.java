package cn.edu.neu.wangzhigang.sssp;
/**
 * The Institute of Computer Software and Theory
 * Northeastern University
 */
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import cn.edu.neu.wangzhigang.util.Edge;
import cn.edu.neu.wangzhigang.util.Vertex;
import cn.edu.neu.wangzhigang.util.VertexState;

/**
 * SSSPMapper
 * This is used for the normal iterator(iterator > 1).
 * The function is to read graph data, process the vertex whose {@link VertexState} is {@link VertexState.ACTIVE}.
 * That means tell the outgoing vertices the new vertexValue.
 * The input <key, value> format is, <key> = [vertexId] and <value> = [vertexValue:vertexState:dstId:weight...].
 * The output <key, value> format is, <key> = [vertexId] and <value> = [vertexValue:vertexState:dstId:weight...].
 * Certainly, the output <key, value> used as messages or the vertex has not outgoing edges is special, 
 * <value> = [vertexValue:vertexState].
 * 
 * For the output <key, value> used as messages, the {@link VertextState} is {@link VertexState.ACTIVE}.
 * While, for other output <key, value>, it is {@link VertexState.UNACTIVE}.
 * 
 * @author Zhigang Wang
 * @version 0.1
 */

public class SSSPMapper extends Mapper<IntWritable, Text, IntWritable, Text> {
	
	@Override
	public void map(IntWritable key, Text value,Context context) 
			throws IOException, InterruptedException {
		Vertex vertex = new Vertex(key.get(), value.toString());
		
		if (vertex.isActive()) {
			for (Edge edge : vertex.getEdges()) {
				Vertex msgVertex = new Vertex(edge.getDstVertexId());
				msgVertex.updateVertexValue(vertex.getVertexValue() + edge.getWeight());
				msgVertex.updateVertexState(VertexState.ACTIVE);
				context.write(new IntWritable(msgVertex.getVertexId()), new Text(msgVertex.toString()));
			}
		}
		
		vertex.updateVertexState(VertexState.UNACTIVE);
		context.write(new IntWritable(vertex.getVertexId()), new Text(vertex.toString()));
	}
}
