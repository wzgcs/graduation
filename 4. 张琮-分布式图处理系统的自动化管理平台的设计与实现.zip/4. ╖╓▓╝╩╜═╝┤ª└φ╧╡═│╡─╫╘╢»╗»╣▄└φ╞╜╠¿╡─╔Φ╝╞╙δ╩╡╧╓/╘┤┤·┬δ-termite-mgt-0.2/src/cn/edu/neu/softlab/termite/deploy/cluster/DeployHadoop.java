package cn.edu.neu.softlab.termite.deploy.cluster;

import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class DeployHadoop extends Thread {
	
	private String hadoopLocalPath;
	private String hadoopDeployPath;
	private DefaultTableModel workerListDTM;
	private JTextArea opResultJTA;
	
	private JFrame jf;
	private Container c;
	
	public DeployHadoop(JFrame parentWin, String hadoopLocalPath, String hadoopDeployPath,
			DefaultTableModel workerListDTM, JTextArea opResultJTA) {
		this.hadoopLocalPath = hadoopLocalPath;
		this.hadoopDeployPath = hadoopDeployPath;
		this.workerListDTM = workerListDTM;
		this.opResultJTA = opResultJTA;
		
		this.jf = new JFrame("Deploying Hadoop Cluster");
		this.jf.setBounds(parentWin.getX() + 150, parentWin.getY() + 350, 500, 100);
		this.c = jf.getContentPane();
		this.c.setLayout(null);
	}
	
	@Override
	public void run() {
		JPanel jp = new JPanel();
		jp.setLayout(null);
		jp.setBounds(10, 0, 480, 75);
		
		JLabel tagJL = new JLabel("Deploying Hadoop cluster, please wait ...");
		tagJL.setBounds(0, 0, 480, 20);
		jp.add(tagJL);
		
		JProgressBar progressbar = new JProgressBar();
        progressbar.setOrientation(JProgressBar.HORIZONTAL);
        progressbar.setMinimum(0);
        progressbar.setMaximum(this.workerListDTM.getRowCount() - 1);
        progressbar.setValue(0);
        progressbar.setStringPainted(true);
        progressbar.setBorderPainted(true);
        progressbar.setBounds(0, 25, 480, 20);
        jp.add(progressbar);
        
        JLabel explain = new JLabel("begin to deploy, 0/" + this.workerListDTM.getRowCount());
        explain.setBounds(0, 50, 480, 20);
        jp.add(explain);
        
        this.c.add(jp);
        this.jf.setVisible(true);
		
		int successCounter = 0, failCounter = 0;
		int index = 0, loop = this.workerListDTM.getRowCount();
		for (; index < loop; index++) {
			explain.setText("deploy on " + this.workerListDTM.getValueAt(index, 0)
					+ ", " + (index + 1) + "/" + this.workerListDTM.getRowCount());
			String command = ("scp -r" + " " + this.hadoopLocalPath 
					+ " " + this.workerListDTM.getValueAt(index, 2) + "@" + this.workerListDTM.getValueAt(index, 1)
					+ ":" + this.hadoopDeployPath);
			String[] cmd = { "/bin/bash", "-c", command };
			try {
				Process pro = Runtime.getRuntime().exec(cmd);
				if(pro.waitFor() == 0){
					opResultJTA.append("Deploy Hadoop on " + this.workerListDTM.getValueAt(index, 1) + " successfully!\n");
					successCounter++;
				}else{
					opResultJTA.append("Deploy Hadoop on " + this.workerListDTM.getValueAt(index, 1) + " fail!\n");
					failCounter++;
				}
				progressbar.setValue(index);
				explain.setText("deploy " + this.workerListDTM.getValueAt(index, 0) + ", " + (index + 1) + "/" + loop);
			} catch (Exception e) {
				opResultJTA.append("Deploy Hadoop on " + this.workerListDTM.getValueAt(index, 1) + " fail!\n");
				failCounter++;
			}
		}
		explain.setText("deploy over" +  ", total:" + loop + ", success:" + successCounter + ", fail:" + failCounter);
	}
}
