package cn.edu.neu.softlab.termite.deploy.action;

import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;

public class SSHExe extends Thread {
	
	private String[] commands ;
	private DefaultTableModel workerListDTM;
	private JTextArea opResultJTA;
	
	private JFrame jf;
	private Container c;
	
	public SSHExe(JFrame parentWin, String[] commands,
			DefaultTableModel workerListDTM, JTextArea opResultJTA) {
		this.commands = commands;
		this.workerListDTM = workerListDTM;
		this.opResultJTA = opResultJTA;
		
		this.jf = new JFrame("SSH Commands Operation");
		this.jf.setBounds(parentWin.getX() + 150, parentWin.getY() + 350, 500, 100);
		this.c = jf.getContentPane();
		this.c.setLayout(null);
	}
	
	@Override
	public void run() {
		JPanel jp = new JPanel();
		jp.setLayout(null);
		jp.setBounds(10, 0, 480, 75);
		
		JLabel tagJL = new JLabel("Executing ssh commands, please wait ...");
		tagJL.setBounds(0, 0, 480, 20);
		jp.add(tagJL);
		
		JProgressBar progressbar = new JProgressBar();
        progressbar.setOrientation(JProgressBar.HORIZONTAL);
        progressbar.setMinimum(0);
        progressbar.setMaximum(this.workerListDTM.getRowCount() - 1);
        progressbar.setValue(0);
        progressbar.setStringPainted(true);
        progressbar.setBorderPainted(true);
        progressbar.setBounds(0, 25, 480, 20);
        jp.add(progressbar);
        
        JLabel explain = new JLabel("begin to execute commands, 0/" + this.workerListDTM.getRowCount());
        explain.setBounds(0, 50, 480, 20);
        jp.add(explain);
        
        this.c.add(jp);
        this.jf.setVisible(true);
		
		int successCounter = 0, failCounter = 0;
		int index = 0, loop = this.workerListDTM.getRowCount();
		for (; index < loop; index++) {
			try {
				explain.setText("execute commands on " + this.workerListDTM.getValueAt(index, 0)
						+ ", " + (index + 1) + "/" + this.workerListDTM.getRowCount());
				Connection conn = new Connection((String) this.workerListDTM.getValueAt(index, 1));
				conn.connect();
				boolean isAuthenticated = conn.authenticateWithPassword(
						(String) this.workerListDTM.getValueAt(index, 2),
						(String) this.workerListDTM.getValueAt(index, 3));
				if (isAuthenticated) {
					Session sess;
					for (int j = 0; j < this.commands.length; j++) {
						sess = conn.openSession();
						sess.execCommand(this.commands[j]);
						sess.close();
					}
				}
				conn.close();
				progressbar.setValue(index);
				opResultJTA.append("Execute commands on " + this.workerListDTM.getValueAt(index, 1) + " successfully!\n");
				successCounter++;
			} catch (Exception e) {
				opResultJTA.append("Execute commands on " + this.workerListDTM.getValueAt(index, 1) + " fail!\n");
				failCounter++;
			}
		}
		
		explain.setText("execute commands over" +  ", total:" + loop + ", success:" + successCounter + ", fail:" + failCounter);
	}
}
