package cn.edu.neu.softlab.termite.deploy.driver;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Vector;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import cn.edu.neu.softlab.termite.deploy.action.CopyExe;
import cn.edu.neu.softlab.termite.deploy.action.SSHExe;
import cn.edu.neu.softlab.termite.deploy.cluster.AddWorker;
import cn.edu.neu.softlab.termite.deploy.cluster.DeployHadoop;
import cn.edu.neu.softlab.termite.deploy.cluster.DeployTermite;
import cn.edu.neu.softlab.termite.deploy.cluster.HadoopConfiguration;
import cn.edu.neu.softlab.termite.deploy.cluster.RemoveWorker;
import cn.edu.neu.softlab.termite.deploy.cluster.SetLinux;
import cn.edu.neu.softlab.termite.deploy.cluster.TermiteConfiguration;
import cn.edu.neu.softlab.termite.deploy.job.SingleJobDetailMonitor;
import cn.edu.neu.softlab.termite.util.Util;


import ch.ethz.ssh2.Connection;

/**
 * This is the main window to deploy the Hadoop and Termite cluseters.
 * @author Zhigang Wang
 * @version 0.1
 */
public class Driver extends JFrame {

	/**
	 * Judge the user-choose button and invoke the relative function.
	 * @author Zhigang Wang
	 * @version 0.1
	 */
	public class ButtonAction implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == pingJMI) {
				ping();
			} else if (e.getSource() == saveJMI) {
				save();
			} else if (e.getSource() == refreshJMI) {
				refresh();
			} else if (e.getSource() == addWorkerJB) {
				addWorker();
			} else if (e.getSource() == removeWorkerJB) {
				removeWorker();
			} else if (e.getSource() == sshExeJB) {
				sshExe();
			} else if (e.getSource() == copyExeJB) {
				copyExe();
			} else if (e.getSource() == clearExeJB) {
				clearExe();
			} else if (e.getSource() == hadoopJMI) {
				setHadoop();
			} else if (e.getSource() == termiteJMI) {
				setTermite();
			} else if (e.getSource() == linuxJMI) {
				setLinux();
			} else if (e.getSource() == scanJMI) {
				scanJobs();
			} else if (e.getSource() == submitJMI) {
				submitJob();
			} else if (e.getSource() == helpJMI) {
				helpContent();
			} else if (e.getSource() == aboutJMI) {
				aboutInfo();
			} else if (e.getSource() == hadoopBrowseJB) {
				hadoopBrowse();
			} else if (e.getSource() == termiteBrowseJB) {
				termiteBrowse();
			} else if (e.getSource() == hadoopDeployJB) {
				hadoopDeploy();
			} else if (e.getSource() == termiteDeployJB) {
				termiteDeploy();
			}
		}
	}

	private static final long serialVersionUID = 1L;
	private static String ToolParentPath = null;
	private static Driver win;
	private Container c = getContentPane();

	private JPanel opClusterJP = new JPanel();
	private JPanel opWorkerJP = new JPanel();
	private JPanel masterNameJP = new JPanel();
	private JPanel deployClusterJP = new JPanel();
	private JPanel userCommandJP = new JPanel();
	private JPanel copyRightJP = new JPanel();
	
	// Operation Workers.
	private JTextField hostNameJTF = new JTextField();
	private JTextField hostIPJTF = new JTextField();
	private JTextField hostAccountJTF = new JTextField();
	private JTextField hostPassWordJTF = new JTextField();
	private JTextField taskNumJTF = new JTextField();
	private JTextField jdkLocationJTF = new JTextField();
	private JButton addWorkerJB = new JButton("Add");
	private JButton removeWorkerJB = new JButton("Remove");
	
	// Display worker list & operation result content.
	JDesktopPane disPlayJDP = new JDesktopPane();
	private String[]  workerListJSPColumnName = {"HostName", "IP", "User", "PassWord", "Tasks", "JDK"};
	private DefaultTableModel workerListDTM = new DefaultTableModel(workerListJSPColumnName, 0);
	private JTable workerListJT = new JTable(workerListDTM);
	private JScrollPane workerListJSP = new JScrollPane();
	private JScrollPane opResultJSP = new JScrollPane();
	private JTextArea opResultJTA = new JTextArea();
	
	// Operation Hadoop and Termite clusters.
	private JTextField hadoopNameNodeJTF = new JTextField();
	private JTextField hadoopServerPortJTF = new JTextField();
	private JTextField hadoopDeployPathJTF = new JTextField();
	private JTextField termiteMasterJTF = new JTextField();
	private JTextField termiteServerPortJTF = new JTextField();
	private JTextField termiteDeployPathJTF = new JTextField();
	
	// Deploy Hadoop and Termite on the new worker(s).
	private JTextField hadoopLocalPathJTF = new JTextField();
	private JTextField termiteLocalPathJTF = new JTextField();
	private JButton hadoopBrowseJB = new JButton("Browse");
	private JButton hadoopDeployJB = new JButton("Deploy");
    private JButton termiteBrowseJB = new JButton("Browse");
    private JButton termiteDeployJB = new JButton("Deploy");
    
	// User-defined commands.
	private JTextArea userCommandJTA = new JTextArea();
	private JScrollPane userCommandJSP = new JScrollPane();
	private JDesktopPane userCommandJDP = new JDesktopPane();
	private JTextArea commCommandJTA = new JTextArea();
	private JScrollPane commCommandJSP = new JScrollPane();
	private JDesktopPane commCommandJDP = new JDesktopPane();
	private JButton sshExeJB = new JButton("EXE");
	private JButton copyExeJB = new JButton("COPY");
	private JButton clearExeJB = new JButton("CLC");
	
	// Menu
	private JMenuBar menuBarJMB = new JMenuBar();
	private JMenu opreationJM = new JMenu("Operation");
	private JMenuItem pingJMI = new JMenuItem("Ping Workers");
	private JMenuItem saveJMI = new JMenuItem("Save All");
	private JMenuItem refreshJMI = new JMenuItem("Refresh");
	
	private JMenu confJM = new JMenu("Configuration");
	private JMenuItem linuxJMI = new JMenuItem("Linux System");
	private JMenuItem hadoopJMI = new JMenuItem("Hadoop Cluster");
	private JMenuItem termiteJMI = new JMenuItem("DiterGraph Cluster");
	
	private JMenu jobJM = new JMenu("JobManager");
	private JMenuItem scanJMI = new JMenuItem("Scan All Jobs");
	private JMenuItem submitJMI = new JMenuItem("Submit One Job");
	
	JMenu helpJM = new JMenu("Help");
	JMenuItem helpJMI = new JMenuItem("User Manual");
	JMenuItem aboutJMI = new JMenuItem("About the Tool");
	
	public Driver() {
		// Set the basic configurations.
		super("DiterGraph Manage&Deploy Tool");
		setBounds(200, 100, 780, 690);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		c.setLayout(null);
		opClusterJP.setLayout(null);
		opWorkerJP.setLayout(null);
		masterNameJP.setLayout(null);
		deployClusterJP.setLayout(null);
		userCommandJP.setLayout(null);
		copyRightJP.setLayout(null);

		// Set the Menu
		setJMenuBar(this.menuBarJMB);
		
		pingJMI.addActionListener(new ButtonAction());
		opreationJM.add(pingJMI);
		opreationJM.addSeparator();
		saveJMI.addActionListener(new ButtonAction());
		opreationJM.add(saveJMI);
		opreationJM.addSeparator();
		refreshJMI.addActionListener(new ButtonAction());
		opreationJM.add(refreshJMI);
		this.menuBarJMB.add(opreationJM);
		
		linuxJMI.addActionListener(new ButtonAction());
		confJM.add(linuxJMI);
		confJM.addSeparator();
		hadoopJMI.addActionListener(new ButtonAction());
		confJM.add(hadoopJMI);
		confJM.addSeparator();
		termiteJMI.addActionListener(new ButtonAction());
		confJM.add(termiteJMI);
		this.menuBarJMB.add(confJM);
		
		scanJMI.addActionListener(new ButtonAction());
		jobJM.add(scanJMI);
		jobJM.addSeparator();
		submitJMI.addActionListener(new ButtonAction());
		jobJM.add(submitJMI);
		this.menuBarJMB.add(jobJM);
		
		helpJMI.addActionListener(new ButtonAction());
		helpJM.add(helpJMI);
		helpJM.addSeparator();
		aboutJMI.addActionListener(new ButtonAction());
		helpJM.add(aboutJMI);
		this.menuBarJMB.add(helpJM);

		// Set the panel of master names and cluster paths.
		masterNameJP.setBounds(10, 15, 500, 150);
		
		JLabel nameJL = new JLabel("The hostname of workers which run Hadoop NameNode & DiterGraph Master");
		nameJL.setBounds(0, 0, 500, 20);
		JLabel hnnJL = new JLabel("HadoopNameNode");
		hnnJL.setBounds(0, 25, 130, 20);
		hadoopNameNodeJTF.setBounds(130, 25, 115, 20);
		hadoopNameNodeJTF.setText("null");
		JLabel tmJL = new JLabel("DiterGraphMaster");
		tmJL.setBounds(255, 25, 130, 20);
		termiteMasterJTF.setBounds(385, 25, 115, 20);
		termiteMasterJTF.setText("null");
		masterNameJP.add(nameJL);
		masterNameJP.add(hnnJL);
		masterNameJP.add(hadoopNameNodeJTF);
		masterNameJP.add(tmJL);
		masterNameJP.add(termiteMasterJTF);
		
		JLabel hspJL = new JLabel("HadoopServerPort");
		hspJL.setBounds(0, 50, 130, 20);
		hadoopServerPortJTF.setBounds(130, 50, 115, 20);
		hadoopServerPortJTF.setText("null");
		JLabel tspJL = new JLabel("DiterGraphPort");
		tspJL.setBounds(255, 50, 130, 20);
		termiteServerPortJTF.setBounds(385, 50, 115, 20);
		termiteServerPortJTF.setText("null");
		masterNameJP.add(hspJL);
		masterNameJP.add(hadoopServerPortJTF);
		masterNameJP.add(tspJL);
		masterNameJP.add(termiteServerPortJTF);
		
		JLabel pathJL = new JLabel("The path of deploying Hadoop & DiterGraph");
		pathJL.setBounds(0, 80, 500, 20);
		JLabel hdpJL = new JLabel("HadoopPath");
		hdpJL.setBounds(0, 105, 130, 20);
		hadoopDeployPathJTF.setBounds(130, 105, 370, 20);
		hadoopDeployPathJTF.setText("null");
		JLabel tdpJL = new JLabel("DiterGraphPath");
		tdpJL.setBounds(0, 130, 130, 20);
		termiteDeployPathJTF.setBounds(130, 130, 370, 20);
		termiteDeployPathJTF.setText("null");
		masterNameJP.add(pathJL);
		masterNameJP.add(hdpJL);
		masterNameJP.add(hadoopDeployPathJTF);
		masterNameJP.add(tdpJL);
		masterNameJP.add(termiteDeployPathJTF);
		
		// Set the worker list and result content.
		disPlayJDP.setBounds(10, 180, 500, 405);
		
		int[] width = new int[]{100, 100, 20, 70, 1, 30};
		TableColumnModel columns = workerListJT.getColumnModel();
	    for (int i = 0; i < width.length; i++) {  
	        TableColumn column = columns.getColumn(i);
	        column.setMinWidth(1);
	        column.setMaxWidth(200);
	        column.setPreferredWidth(width[i]);
	    }
		workerListJT.setColumnModel(columns);
		workerListJSP.setViewportView(workerListJT);
		JInternalFrame workerListJIF = new JInternalFrame("Worker List", false, false, false, false);
		workerListJIF.setBounds(0, 0, 500, 260);
		workerListJIF.setVisible(true);
		workerListJIF.add(workerListJSP, BorderLayout.CENTER);
		disPlayJDP.add(workerListJIF);
		
		opResultJTA.setLineWrap(true);
		opResultJSP.setViewportView(opResultJTA);
		JInternalFrame opResultJIF = new JInternalFrame("Operation Result",	false, false, false, false);
		opResultJIF.setVisible(true);				
		opResultJIF.setBounds(0, 260, 500, 145);
		opResultJIF.add(opResultJSP);
		disPlayJDP.add(opResultJIF);

		// Set the panel of operating Worker List
		opWorkerJP.setBounds(530, 15, 250, 170);
		JLabel hnJL = new JLabel("HostName");
		hnJL.setBounds(0, 0, 80, 20);
		hostNameJTF.setBounds(85, 0, 145, 20);
		opWorkerJP.add(hnJL);
		opWorkerJP.add(hostNameJTF);

		JLabel hipJL = new JLabel("HostIP");
		hipJL.setBounds(0, 25, 80, 20);
		hostIPJTF.setBounds(85, 25, 145, 20);
		opWorkerJP.add(hipJL);
		opWorkerJP.add(hostIPJTF);

		JLabel aJL = new JLabel("Account");
		aJL.setBounds(0, 50, 80, 20);
		hostAccountJTF.setBounds(85, 50, 145, 20);
		opWorkerJP.add(aJL);
		opWorkerJP.add(hostAccountJTF);

		JLabel pwJL = new JLabel("PassWord");
		pwJL.setBounds(0, 75, 80, 20);
		hostPassWordJTF.setBounds(85, 75, 145, 20);
		opWorkerJP.add(pwJL);
		opWorkerJP.add(hostPassWordJTF);
		
		JLabel tnJL = new JLabel("TaskNum");
		tnJL.setBounds(0, 100, 80, 20);
		taskNumJTF.setBounds(85, 100, 145, 20);
		opWorkerJP.add(tnJL);
		opWorkerJP.add(taskNumJTF);
		
		JLabel jdkJL = new JLabel("JDK");
		jdkJL.setBounds(0, 125, 80, 20);
		jdkLocationJTF.setBounds(85, 125, 145, 20);
		opWorkerJP.add(jdkJL);
		opWorkerJP.add(jdkLocationJTF);

		addWorkerJB.setBounds(10, 150, 90, 20);
		addWorkerJB.addActionListener(new ButtonAction());
		removeWorkerJB.setBounds(130, 150, 90, 20);
		removeWorkerJB.addActionListener(new ButtonAction());
		opWorkerJP.add(addWorkerJB);
		opWorkerJP.add(removeWorkerJB);
		
		// Set the panel of deploying Hadoop and Termite clusters.
		deployClusterJP.setBounds(530, 190, 235, 122);
		JLabel dcTag = new JLabel("Deploy Hadoop & DiterGraph");
		dcTag.setBounds(40, 0, 195, 20);
		deployClusterJP.add(dcTag);
		
		JLabel hJL = new JLabel("Hadoop");
		hJL.setBounds(0, 25, 50, 20);
		hadoopLocalPathJTF.setBounds(52, 25, 183, 20);
		hadoopBrowseJB.setBounds(52, 47, 80, 20);
		hadoopBrowseJB.addActionListener(new ButtonAction());
		hadoopDeployJB.setBounds(155, 47, 80, 20);
		hadoopDeployJB.addActionListener(new ButtonAction());
		deployClusterJP.add(hJL);
		deployClusterJP.add(hadoopLocalPathJTF);
		deployClusterJP.add(hadoopBrowseJB);
		deployClusterJP.add(hadoopDeployJB);
		
		JLabel termiteTag = new JLabel("DiterGraph");
		termiteTag.setBounds(0, 80, 70, 20);
		termiteLocalPathJTF.setBounds(72, 80, 163, 20);
		termiteBrowseJB.setBounds(52, 102, 80, 20);
		termiteBrowseJB.addActionListener(new ButtonAction());
		termiteDeployJB.setBounds(155, 102, 80, 20);
		termiteDeployJB.addActionListener(new ButtonAction());
		deployClusterJP.add(termiteTag);
		deployClusterJP.add(termiteLocalPathJTF);
		deployClusterJP.add(termiteBrowseJB);
		deployClusterJP.add(termiteDeployJB);
		
		// Set the panel of user-defined command.
		userCommandJTA.setLineWrap(true);
		userCommandJSP.setViewportView(userCommandJTA);
		userCommandJDP.setBounds(530, 320, 235, 105);
		JInternalFrame userCommandJIF = new JInternalFrame("User-Defined Command", false, false, false, false);
		userCommandJIF.setBounds(0, 0, 235, 105);
		userCommandJIF.setVisible(true);
		userCommandJIF.add(userCommandJSP, BorderLayout.CENTER);
		userCommandJDP.add(userCommandJIF);

		userCommandJP.setBounds(530, 430, 235, 20);
		sshExeJB.setBounds(0, 0, 60, 20);
		sshExeJB.addActionListener(new ButtonAction());
		copyExeJB.setBounds(82, 0, 70, 20);
		copyExeJB.addActionListener(new ButtonAction());
		clearExeJB.setBounds(175, 0, 60, 20);
		clearExeJB.addActionListener(new ButtonAction());
		userCommandJP.add(sshExeJB);
		userCommandJP.add(copyExeJB);
		userCommandJP.add(clearExeJB);
		
		commCommandJTA.setLineWrap(true);
		commCommandJSP.setViewportView(commCommandJTA);
		commCommandJDP.setBounds(530, 455, 235, 130);
		JInternalFrame commCommandJIF = new JInternalFrame("Common Commands Set", false, false, false, false);
		commCommandJIF.setBounds(0, 0, 235, 130);
		commCommandJIF.setVisible(true);
		commCommandJIF.add(commCommandJSP, BorderLayout.CENTER);
		commCommandJDP.add(commCommandJIF);
		
		// Set the panel of copy right.
		copyRightJP.setBounds(0, 595, 780, 60);
		JLabel crJL = new JLabel(Util.Tool.COPYRIGHT_INFO + ", " 
				+ Util.Tool.VERSION_INFO, SwingConstants.CENTER);
		crJL.setBounds(0, 0, 780, 20);
		JLabel authorJL = new JLabel(Util.Tool.ADDRESS + ", " 
				+ Util.Tool.EMAIL, SwingConstants.CENTER);
		authorJL.setBounds(0, 20, 780, 20);
		copyRightJP.add(crJL);
		copyRightJP.add(authorJL);

		// Add all panels.
		c.add(opClusterJP);
		c.add(masterNameJP);
		c.add(disPlayJDP);
		c.add(opWorkerJP);
		c.add(deployClusterJP);
		c.add(userCommandJDP);
		c.add(userCommandJP);
		c.add(commCommandJDP);
		c.add(copyRightJP);
		
		ToolParentPath = getParentPath(this.getClass());
		refresh();
	}

	public void ping() {
		boolean success = false;
		int loop = workerListJT.getRowCount();
		for (int index = 0; index < loop; index++) {
			try {
				Connection conn = new Connection((String) workerListJT.getValueAt(index, 1));
				conn.connect();
				conn.close();
			} catch (Exception e) {
				this.opResultJTA.append("Fail to connect: " + workerListJT.getValueAt(index, 0) + "\n");
				success = true;
				JOptionPane.showMessageDialog(win, "ERROR!\nFail to connect: "
						+ workerListJT.getValueAt(index, 0) + "!");
			}
		}
		
		if (!success) {
			JOptionPane.showMessageDialog(win,
					"SUCCESS!\nAll workers are normal!");
		}
	}

	public void save() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to save the current information?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		try {
			File fileRoot = new File(ToolParentPath + "/" + Util.Tool.DEPLOY_CACHE_DIR);
			if (!fileRoot.exists()) {
					fileRoot.mkdirs();
				}
				File file = new File(fileRoot, Util.Tool.DEPLOY_CACHE_File);
				if (!file.exists()) {
					file.createNewFile();
				}
				FileWriter fw = new FileWriter(file);
				BufferedWriter bw = new BufferedWriter(fw, 65536);
				
				bw.write(Util.Tool.MASTER_NAME_HEADER + "\t" + this.hadoopNameNodeJTF.getText()
						+ "\t" + this.termiteMasterJTF.getText());
				bw.newLine();
				bw.write(Util.Tool.MASTER_SERVER_PORT_HEADER + "\t" + this.hadoopServerPortJTF.getText()
						+ "\t" + this.termiteServerPortJTF.getText());
				bw.newLine();
				bw.write(Util.Tool.HADOOP_DEPLOY_PATH_HEADER + "\t" + this.hadoopDeployPathJTF.getText());
				bw.newLine();
				bw.write(Util.Tool.TERMITE_DEPLOY_PATH_HEADER + "\t" + this.termiteDeployPathJTF.getText());
				bw.newLine();
				
				int loop = this.workerListDTM.getRowCount();
				for (int index = 0; index < loop; index++) {
					bw.write(this.workerListDTM.getValueAt(index, 0) + "\t" + this.workerListDTM.getValueAt(index, 1)
							+ "\t" + this.workerListDTM.getValueAt(index, 2)
							+ "\t" + this.workerListDTM.getValueAt(index, 3)
							+ "\t" + this.workerListDTM.getValueAt(index, 4)
							+ "\t" + this.workerListDTM.getValueAt(index, 5));
					bw.newLine();
				}
				bw.close();
				fw.close();
				
				file = new File(fileRoot, Util.Tool.COMMANDS_CACHE_FILE);
				if (!file.exists()) {
					file.createNewFile();
				}
				fw = new FileWriter(file);
				bw = new BufferedWriter(fw);
				String[] commands = this.commCommandJTA.getText().split("\n");
				for (int i = 1; i < commands.length; i++) {
					bw.write(commands[i]);
					bw.newLine();
				}
				bw.close();
				fw.close();
				
				JOptionPane.showMessageDialog(win, "Save data successfully!");	
			} catch (Exception e) {
				JOptionPane.showMessageDialog(win, "ERROR! Fail to save!");
			}	
	}

	private String searchJDKLocation(String workerName, String ipAddress, String userName) {
		String result = null;
		String command = "scp " + userName + "@" + ipAddress + ":/etc/" + Util.Tool.LINUX_CHECK_FILE
				+ " " + ToolParentPath + "/" + Util.Tool.DEPLOY_TEMP_DIR + "/";
		String[] cmd={"/bin/bash","-c",command};
		try{
			Process p = Runtime.getRuntime().exec(cmd);
			if (p.waitFor() != 0) {
				throw new Exception("Fail");
			}
			File file = new File(ToolParentPath + "/" + Util.Tool.DEPLOY_TEMP_DIR + "/" + Util.Tool.LINUX_CHECK_FILE);
			FileReader fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr, 65536);
			String read;
			while((read = br.readLine()) != null) {
				int index = read.indexOf(Util.Tool.JDK_HOME_CHECK_HEADER);
				if (index != -1) {
					result = read.substring(index + 10);
					break;
				}
			}
			br.close();
			fr.close();
			//file.delete();
		}catch(Exception e){
			this.opResultJTA.append("Fail to fetch JDK's path at worker: "+ workerName + "\n");
			this.opResultJTA.append(command + "\n");
			JOptionPane.showMessageDialog(win, "ERROR!\nFail to fetch JDK's path at worker: "+ workerName + " !");
		}	
		return result;
	}
	
	public void refresh() {
		try {
				File tmpDir = new File(ToolParentPath + "/" + Util.Tool.DEPLOY_TEMP_DIR);
				if (!tmpDir.exists()) {
					tmpDir.mkdirs();
				}
				
				File file = new File(ToolParentPath + "/" + Util.Tool.DEPLOY_CACHE_DIR + "/" + Util.Tool.DEPLOY_CACHE_File);
				if (!file.exists()) {
					JOptionPane.showMessageDialog(win,
							"ERROR! The file: " + file.toString() + " is not exist!");
					return;
				}
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr, 65536);
				String read;
				Vector<String> row;
				int loop = this.workerListDTM.getRowCount();
				for (int index = 0; index < loop; index++) {
					this.workerListDTM.removeRow(0);
				}
				while ((read = br.readLine()) != null) {
					String[] tmp = read.split("\t");
					
					if (tmp[0].equals(Util.Tool.MASTER_NAME_HEADER)) {
						this.hadoopNameNodeJTF.setText(tmp[1]);
						this.termiteMasterJTF.setText(tmp[2]);
						continue;
					}
					if (tmp[0].equals(Util.Tool.MASTER_SERVER_PORT_HEADER)) {
						this.hadoopServerPortJTF.setText(tmp[1]);
						this.termiteServerPortJTF.setText(tmp[2]);
						continue;
					}
					if (tmp[0].equals(Util.Tool.HADOOP_DEPLOY_PATH_HEADER)) {
						this.hadoopDeployPathJTF.setText(tmp[1]);
						continue;
					}
					if (tmp[0].equals(Util.Tool.TERMITE_DEPLOY_PATH_HEADER)) {
						this.termiteDeployPathJTF.setText(tmp[1]);
						continue;
					}
					
					row = new Vector<String>();
					if (tmp.length == 5) {
						row.add(tmp[0]);
						row.add(tmp[1]);
						row.add(tmp[2]);
						row.add(tmp[3]);
						row.add(tmp[4]);
						String jdk = searchJDKLocation(tmp[0], tmp[1], tmp[2]);
						if (jdk != null) {
							row.add(jdk);
						}
						this.workerListDTM.addRow(row);
					} else if (tmp.length == 6) {
						row.add(tmp[0]);
						row.add(tmp[1]);
						row.add(tmp[2]);
						row.add(tmp[3]);
						row.add(tmp[4]);
						row.add(tmp[5]);
						this.workerListDTM.addRow(row);
					} else {
						JOptionPane.showMessageDialog(win, "Invalid information: " + read);
					}
				}
				br.close();
				fr.close();
				
				file = new File(ToolParentPath + "/" + Util.Tool.DEPLOY_CACHE_DIR + "/" + Util.Tool.COMMANDS_CACHE_FILE);
				if (!file.exists()) {
					JOptionPane.showMessageDialog(win,
							"ERROR! The file: " + file.toString() + " is not exist!");
					return;
				}
				fr = new FileReader(file);
				br = new BufferedReader(fr);
				this.commCommandJTA.setText("Account@IP is replaced with " + Util.Tool.COPY_REPLACE_VALUE);
				while ((read = br.readLine()) != null) {
					this.commCommandJTA.append("\n" + read);
				}
				br.close();
				fr.close();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(win, "ERROR! Fail to read!");
			}
	}

	public void setHadoop() {
		int index = 0, loop = this.workerListDTM.getRowCount();
		for (; index < loop; index++) {
			if (this.workerListDTM.getValueAt(index, 0).equals(this.hadoopNameNodeJTF.getText())) {
				break;
			}
		}
		
		@SuppressWarnings("unused")
		HadoopConfiguration conf = new HadoopConfiguration(this, this.hadoopNameNodeJTF.getText().toString(),
				this.workerListDTM.getValueAt(index, 1).toString(), this.workerListDTM.getValueAt(index, 2).toString(),
				this.hadoopDeployPathJTF.getText().toString(), ToolParentPath, this.workerListDTM, this.opResultJTA);
	}
	
	public void setTermite() {
		int index = 0, loop = this.workerListDTM.getRowCount();
		for (; index < loop; index++) {
			if (this.workerListDTM.getValueAt(index, 0).equals(this.termiteMasterJTF.getText())) {
				break;
			}
		}
		
		@SuppressWarnings("unused")
		TermiteConfiguration conf = new TermiteConfiguration(this, this.termiteMasterJTF.getText().toString(),
				this.workerListDTM.getValueAt(index, 1).toString(), this.workerListDTM.getValueAt(index, 2).toString(),
				this.termiteDeployPathJTF.getText().toString(), ToolParentPath, this.workerListDTM, this.opResultJTA);
	}
	
	public void setLinux() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to set the Linux system profile?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		SetLinux sl = new SetLinux(this, ToolParentPath,
				this.hadoopDeployPathJTF.getText().toString(), this.termiteDeployPathJTF.getText().toString(),
				this.workerListDTM, this.opResultJTA);
		sl.start();
	}
	
	public void addWorker() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to add this worker?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		Vector<String> row = new Vector<String>();
		row.add(hostNameJTF.getText());
		row.add(hostIPJTF.getText());
		row.add(hostAccountJTF.getText());
		row.add(hostPassWordJTF.getText());
		row.add(taskNumJTF.getText());
		if (jdkLocationJTF.getText().toString().length() == 0) {
			String location = searchJDKLocation(hostNameJTF.getText().toString(), hostIPJTF.getText().toString(),
					hostAccountJTF.getText().toString());
			jdkLocationJTF.setText(location);
		}
		row.add(jdkLocationJTF.getText());
		try {
			AddWorker newWorker = new AddWorker(hostAccountJTF.getText().toString(), hostIPJTF.getText().toString(), hostNameJTF.getText().toString(),
					this.hadoopLocalPathJTF.getText().toString(), this.hadoopDeployPathJTF.getText().toString(),
					this.termiteLocalPathJTF.getText().toString(), this.termiteDeployPathJTF.getText().toString());
			
			SetLinux sl = new SetLinux(this, ToolParentPath,
					this.hadoopDeployPathJTF.getText().toString(), this.termiteDeployPathJTF.getText().toString(),
					this.workerListDTM, this.opResultJTA);
			sl.setLinuxProfile(hostNameJTF.getText().toString(), hostIPJTF.getText().toString(), hostAccountJTF.getText().toString());
			newWorker.deployHadoopTermite();
			
			int index = 0, hadoopIndex = 0, termiteIndex = 0, loop = this.workerListDTM.getRowCount();
			for (; index < loop; index++) {
				if (this.workerListDTM.getValueAt(index, 0).equals(this.hadoopNameNodeJTF.getText())) {
					hadoopIndex = index;
				}
				if (this.workerListDTM.getValueAt(index, 0).equals(this.termiteMasterJTF.getText())) {
					termiteIndex = index;
				}
			}
			newWorker.changeWorkermanager(ToolParentPath, this.workerListDTM.getValueAt(hadoopIndex, 1).toString(),
					this.workerListDTM.getValueAt(hadoopIndex, 2).toString(),
					this.workerListDTM.getValueAt(termiteIndex, 1).toString(), this.workerListDTM.getValueAt(termiteIndex, 2).toString());
			this.workerListDTM.addRow(row);
			save();
			JOptionPane.showMessageDialog(win, "Add " + hostNameJTF.getText()
					+ " successfully!");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(win, "ERROR!\nFail to add the new worker:" + hostNameJTF.getText() + "!");
			//e.printStackTrace();
		}
	}

	public void removeWorker() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to remove this worker?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		String deleteHost = hostNameJTF.getText();
		int flag = 0, loop = this.workerListDTM.getRowCount();
		if ((deleteHost != null) && (!deleteHost.equals(""))) {
			for (flag = 0; flag < loop; flag++) {
				if (this.workerListDTM.getValueAt(flag, 0).equals(deleteHost)) {
					break;
				}
			}
		} else {
			JOptionPane.showMessageDialog(win, "ERROR! Please input the HostName!");
			return;
		}
		
		try {
			RemoveWorker removeWorker = new RemoveWorker(this.workerListDTM.getValueAt(flag, 2).toString(),
					this.workerListDTM.getValueAt(flag, 1).toString(), this.workerListDTM.getValueAt(flag, 0).toString(),
					this.hadoopLocalPathJTF.getText().toString(), this.hadoopDeployPathJTF.getText().toString(),
					this.termiteLocalPathJTF.getText().toString(), this.termiteDeployPathJTF.getText().toString());
			removeWorker.closeDaemon();
			
			int index, hadoopIndex = 0, termiteIndex = 0;
			loop = this.workerListDTM.getRowCount();
			for (index = 0; index < loop; index++) {
				if (this.workerListDTM.getValueAt(index, 0).equals(this.hadoopNameNodeJTF.getText())) {
					hadoopIndex = index;
				}
				if (this.workerListDTM.getValueAt(index, 0).equals(this.termiteMasterJTF.getText())) {
					termiteIndex = index;
				}
			}
			removeWorker.changeWorkermanager(ToolParentPath, this.workerListDTM.getValueAt(hadoopIndex, 1).toString(),
					this.workerListDTM.getValueAt(hadoopIndex, 2).toString(),
					this.workerListDTM.getValueAt(termiteIndex, 1).toString(), this.workerListDTM.getValueAt(termiteIndex, 2).toString());
			this.workerListDTM.removeRow(flag);
			save();
			JOptionPane.showMessageDialog(win, "Remove " + hostNameJTF.getText()
					+ " successfully!");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(win, "ERROR!\nFail to remove the new worker:" + hostNameJTF.getText() + "!");
			//e.printStackTrace();
		}
	}

	public void copyExe() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to copy?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		String[] commands = userCommandJTA.getText().split("\n");
		CopyExe ce = new CopyExe(this, commands, this.workerListDTM, this.opResultJTA);
		ce.start();
	}

	public void sshExe() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to execute these commands?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		String[] commands = userCommandJTA.getText().split("\n");
		SSHExe se = new SSHExe(this, commands, this.workerListDTM, this.opResultJTA);
		se.start();
	}
	
	public void clearExe() {
		userCommandJTA.setText("");
	}
	
	public void hadoopBrowse() {
		String dir = "/home";
		Component parent = null;
		JFileChooser chooser = new JFileChooser(dir);
		javax.swing.filechooser.FileFilter dirFilter = new javax.swing.filechooser.FileFilter() {
			public boolean accept(File f) {
				return f.isDirectory();
			}

			public String getDescription() {
				return "";
			}
		};
		
		chooser.setFileFilter(dirFilter);
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		
		if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
			dir = chooser.getSelectedFile().getAbsolutePath();
		}
		this.hadoopLocalPathJTF.setText(dir);
	}
	
	public void termiteBrowse() {
		String dir = "/home";
		Component parent = null;
		JFileChooser chooser = new JFileChooser(dir);
		javax.swing.filechooser.FileFilter dirFilter = new javax.swing.filechooser.FileFilter() {
			public boolean accept(File f) {
				return f.isDirectory();
			}

			public String getDescription() {
				return "";
			}
		};
		
		chooser.setFileFilter(dirFilter);
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		
		if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
			dir = chooser.getSelectedFile().getAbsolutePath();
		}
		this.termiteLocalPathJTF.setText(dir);
	}

	public void hadoopDeploy() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to deploy Hadoop?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		if (this.hadoopLocalPathJTF.getText().toString().length() == 0 || this.hadoopDeployPathJTF.getText().toString().length() == 0) {
			JOptionPane.showMessageDialog(win,"Sorry!\nPlease set the loacl path & deploy path!");
			return;
		}
		
		DeployHadoop dh = new DeployHadoop(this, this.hadoopLocalPathJTF.getText().toString(),
				this.hadoopDeployPathJTF.getText().toString(),
				this.workerListDTM, this.opResultJTA);
		dh.start();
	}
	
	public void termiteDeploy() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to deploy Termite?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		if (this.termiteLocalPathJTF.getText().toString().length() == 0 || this.termiteDeployPathJTF.getText().toString().length() == 0) {
			JOptionPane.showMessageDialog(win,"Sorry!\nPlease set the source path & output path!");
			return;
		}
		
		DeployTermite dt = new DeployTermite(this, this.termiteLocalPathJTF.getText().toString(),
				this.termiteDeployPathJTF.getText().toString(),
				this.workerListDTM, this.opResultJTA);
		dt.start();
	}
	
	public void scanJobs() {
		SingleJobDetailMonitor singleJobMonitor = new SingleJobDetailMonitor(this.hostNameJTF.getText().toString(),
				this.termiteMasterJTF.getText().toString(), this.termiteServerPortJTF.getText().toString());
		singleJobMonitor.start();
	}
	
	public void submitJob() {
		
	}
	
	public void helpContent() {
		
	}
	
	public void aboutInfo() {
		
	}
	
	@SuppressWarnings("unchecked")
	public String getParentPath(Class cls){
		ClassLoader loader=cls.getClassLoader();
		String clsName=cls.getName()+".class";    
	    Package pack=cls.getPackage();   
	    String path="";     
	    if(pack!=null){   
	        String packName=pack.getName();   
	        clsName=clsName.substring(packName.length()+1);  
	        if(packName.indexOf(".")<0){
	        	path=packName+"/";   
	        }else{
	        	int start=0,end=0;   
	            end=packName.indexOf(".");   
	            while(end!=-1){   
	                path=path+packName.substring(start,end)+"/";   
	                start=end+1;   
	                end=packName.indexOf(".",start);   
	            }   
	            path=path+packName.substring(start)+"/";   
	        }   
	    }   
	    java.net.URL url =loader.getResource(path+clsName);     
	    String realPath=url.getPath();     
	    int pos=realPath.indexOf("file:");   
	    if(pos>-1) realPath=realPath.substring(pos+5);      
	    pos=realPath.indexOf(path+clsName);   
	    realPath=realPath.substring(0,pos-1);     
	    if(realPath.endsWith("!")){
	    	realPath=realPath.substring(0,realPath.lastIndexOf("/"));
	    }
	    try{
	    	realPath=java.net.URLDecoder.decode(realPath,"utf-8");   
	    }catch(Exception e){
	    	throw new RuntimeException(e);
	    }   
	   return realPath;
	}
	
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				win = new Driver();
				win.setVisible(true);
			}
		});
	}
}
