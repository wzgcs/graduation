package cn.edu.neu.softlab.termite.deploy.cluster;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import cn.edu.neu.softlab.termite.util.Util;

public class AddWorker {
		String newUserName;
		String newIpAddress;
		String newHostName;
		String hadoopLocalPath;
		String hadoopDeployPath;
		String termiteLocalPath;
		String termiteDeployPath;
		
		public  AddWorker(String newUserName, String newIpAddress, String newHostName,
				String hadoopLocalPath, String hadoopDeployPath, String termiteLocalPath, String termiteDeployPath) {
			this.newUserName = newUserName;
			this.newIpAddress = newIpAddress;
			this.newHostName = newHostName;
			
			this.hadoopLocalPath = hadoopLocalPath;
			this.hadoopDeployPath = hadoopDeployPath;
			this.termiteLocalPath = termiteLocalPath;
			this.termiteDeployPath = termiteDeployPath;
		}
		
		public void deployHadoopTermite() throws Exception {
			// copy system
			/*String command_scp_hadoop = ("scp -r" + " " + this.hadoopSourcePath 
					+ " " + this.newUserName + "@" + this.newIpAddress + ":" + this.hadoopDstPath);*/
			String command_scp_termite = ("scp -r" + " " + this.termiteLocalPath 
					+ " " + this.newUserName + "@" + this.newIpAddress + ":" + this.termiteDeployPath);
			
			//String cmd1[] = {"/bin/bash", "-c", command_scp_hadoop};
			String cmd2[] = {"/bin/bash", "-c", command_scp_termite};
			//System.out.println(command_scp_hadoop);
			//System.out.println(command_scp_bcbsp);
			//Process pro_hadoop = Runtime.getRuntime().exec(cmd1);
			Process pro_termite  = Runtime.getRuntime().exec(cmd2);
			//pro_hadoop.waitFor();
			if (pro_termite.waitFor() != 0) {
				throw new Exception("Fail");
			}
			
			// start hdfs & workerManager
			/*String command_start_hdfs = ("ssh -l " + this.newUserName + " " + this.newIpAddress  + " " + "\"" 
					+ "$HADOOP_HOME/bin/hadoop-daemon.sh start datenode" + "\"");*/
			String command_start_termite = ("ssh -l " + this.newUserName + " " + this.newIpAddress  + " " + "\"" 
					+ "$TERMITE_HOME/bin/termite-daemon.sh start worker" + "\"");
			//String cmd3[] = {"/bin/bash", "-c", command_start_hdfs};
			String cmd4[] = {"/bin/bash", "-c", command_start_termite};
			//pro_hadoop = Runtime.getRuntime().exec(cmd3);
			pro_termite  = Runtime.getRuntime().exec(cmd4);
			//pro_hadoop.waitFor();
			if (pro_termite.waitFor() != 0) {
				throw new Exception("Fail");
			}
		}
		
		public void changeWorkermanager(String rootPath, String hadoopIP, String hadoopUserName,
				String termiteIP, String termiteUserName) throws Exception {
			String command = null;
			String[] cmd = {"/bin/bash", "-c", command};
			Process p;
			
			// change Hadoop
			command = "scp " + hadoopUserName + "@" + hadoopIP + ":" + this.hadoopDeployPath + "/" + Util.HadoopConf.HADOOP_CONF_DIR + "/"
					+ Util.HadoopConf.HADOOP_CONF_SLAVES_FILE + " " + rootPath + "/"
					+ Util.Tool.DEPLOY_TEMP_DIR + "/";
			cmd[2] = command;
			p = Runtime.getRuntime().exec(cmd);
			if (p.waitFor() != 0) {
				throw new Exception("Fail");
			}
			
			File hadoopFile = new File(rootPath + "/" + Util.Tool.DEPLOY_TEMP_DIR, Util.HadoopConf.HADOOP_CONF_SLAVES_FILE);
			FileWriter hadoopFW = new FileWriter(hadoopFile, true);
			BufferedWriter hadoopBW = new BufferedWriter(hadoopFW);
			hadoopBW.write(this.newHostName);
			hadoopBW.close();
			hadoopFW.close();
			
			command = "scp " + hadoopFile.toString() + " " + hadoopUserName
					+ "@" + hadoopIP + ":" + this.hadoopDeployPath + "/" + Util.HadoopConf.HADOOP_CONF_DIR + "/";
			cmd[2] = command;
			p = Runtime.getRuntime().exec(cmd);
			if (p.waitFor() != 0) {
				throw new Exception("Fail");
			}
			hadoopFile.delete();
			
			// change BCBSP
			command = "scp " + termiteUserName + "@" + termiteIP + ":" + this.termiteDeployPath + "/" + Util.TermiteConf.TERMITE_CONF_DIR + "/"
				+ Util.TermiteConf.TERMITE_CONF_WORKERS_FILE+ " " + rootPath + "/"
				+ Util.Tool.DEPLOY_TEMP_DIR + "/";
			cmd[2] = command;
			p = Runtime.getRuntime().exec(cmd);
			if (p.waitFor() != 0) {
				throw new Exception("Fail");
			}
	
			File bcbspFile = new File(rootPath + "/" + Util.Tool.DEPLOY_TEMP_DIR, Util.TermiteConf.TERMITE_CONF_WORKERS_FILE);
			FileWriter bcbspFW = new FileWriter(bcbspFile, true);
			BufferedWriter bcbspBW = new BufferedWriter(bcbspFW);
			bcbspBW.write(this.newHostName);
			bcbspBW.close();
			bcbspFW.close();
	
			command = "scp " + bcbspFile.toString() + " " + termiteUserName
					+ "@" + termiteIP + ":" + this.termiteDeployPath + "/" + Util.TermiteConf.TERMITE_CONF_DIR + "/";
			cmd[2] = command;
			p = Runtime.getRuntime().exec(cmd);
			if (p.waitFor() != 0) {
				throw new Exception("Fail");
			}
			bcbspFile.delete();
		}
}