package cn.edu.neu.softlab.termite.deploy.cluster;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import cn.edu.neu.softlab.termite.util.Util;

public class HadoopConfiguration {

	public class ButtonAction implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == updateJB) {
				update();
			} else if (e.getSource() == cancelJB) {
				cancel();
			}
		}
	}

	public class WindowAction implements WindowListener {

		public void windowClosing(WindowEvent e) {
			clean();
		}

		public void windowActivated(WindowEvent e) {};
		public void windowClosed(WindowEvent e) {};
		public void windowDeactivated(WindowEvent e) {};
		public void windowDeiconified(WindowEvent e) {};
		public void windowIconified(WindowEvent e) {};
		public void windowOpened(WindowEvent e) {};
	}

	private JFrame frame;
	private Container c;

	private JPanel topJP = new JPanel();
	private JPanel bottomJP = new JPanel();

	private String[] paramListColumnName = { "Name", "Value", "File" };
	private DefaultTableModel paramListDTM = new DefaultTableModel(paramListColumnName, 0);
	private JTable paramListJT = new JTable(paramListDTM);
	private JScrollPane paramListJSP = new JScrollPane();
	private JDesktopPane paramListJDP = new JDesktopPane();

	private JButton updateJB = new JButton("Update");
	private JButton cancelJB = new JButton("Cancel");
	
	private static String ToolParentPath = null;
	private String hadoopDeployPath = null;
	private DefaultTableModel workerListDTM;
	private JTextArea opResultJTA;
	
	public HadoopConfiguration(JFrame father, String masterName,	String ipAddress, String userName,
			String hadoopDeployPath, String toolParentPath, DefaultTableModel workerListDTM, JTextArea opResultJTA) {
		ToolParentPath = toolParentPath;
		this.hadoopDeployPath = hadoopDeployPath;
		this.workerListDTM = workerListDTM;
		this.opResultJTA = opResultJTA;
		this.frame = new JFrame("Configurate Hadoop Cluster");
		this.frame.setBounds(new Rectangle(
				(int) father.getBounds().getX() + 50, (int) father.getBounds()
						.getY() + 50, (int) father.getBounds().getWidth(), 555));

		this.c = this.frame.getContentPane();

		this.frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.c.setLayout(null);

		this.topJP.setLayout(null);
		this.bottomJP.setLayout(null);

		initialize(masterName, ipAddress, userName);

		this.c.add(this.topJP);
		this.c.add(this.paramListJDP);
		this.c.add(this.bottomJP);
		this.frame.addWindowListener(new WindowAction());
		this.frame.setVisible(true);
	}

	private void initialize(String masterName, String ipAddress, String userName) {
		this.topJP.setBounds(10, 10, 750, 20);
		JLabel topJL = new JLabel(
				"Read the current configuration on NameNode: "
						+ masterName + ":" + this.hadoopDeployPath);
		topJL.setBounds(0, 0, 750, 20);
		this.topJP.add(topJL);

		this.paramListJSP.setViewportView(this.paramListJT);
		this.paramListJDP.setBounds(10, 35, 750, 400);
		JInternalFrame paramListJIF = new JInternalFrame(
				"Advanced parameters", false, false, false, false);
		paramListJIF.setBounds(0, 0, 750, 400);
		paramListJIF.setVisible(true);
		paramListJIF.add(this.paramListJSP, BorderLayout.CENTER);
		this.paramListJDP.add(paramListJIF);
		readDefaultConf(masterName, ipAddress, userName);

		this.bottomJP.setBounds(10, 440, 750, 70);
		JLabel total = new JLabel("Total " + this.paramListDTM.getRowCount()
				+ " configuration items");
		JLabel note_one = new JLabel(
				"Note: the following parameters will be set according to WorkerServer List");
		JLabel note_two = new JLabel("        *the path of JDK in hadoop-env.sh");
		total.setBounds(0, 0, 550, 20);
		note_one.setBounds(0, 25, 550, 13);
		note_two.setBounds(0, 40, 550, 13);
		this.bottomJP.add(total);
		this.bottomJP.add(note_one);
		this.bottomJP.add(note_two);
		this.updateJB.setBounds(560, 25, 80, 20);
		this.updateJB.addActionListener(new ButtonAction());
		this.cancelJB.setBounds(670, 25, 80, 20);
		this.cancelJB.addActionListener(new ButtonAction());
		this.bottomJP.add(this.updateJB);
		this.bottomJP.add(this.cancelJB);
	}

	/**
	 * Read the configuration file(bcbsp-site.xml) from the BSPController.
	 */
	private void readDefaultConf(String masterName, String ipAddress, String userName) {
		readFile(masterName, userName, ipAddress, Util.HadoopConf.HADOOP_CONF_CORE_FILE);
		readFile(masterName, userName, ipAddress, Util.HadoopConf.HADOOP_CONF_HDFS_FILE);
		readFile(masterName, userName, ipAddress, Util.HadoopConf.HADOOP_CONF_MAPRED_FILE);
	}

	private void readFile(String masterName, String userName, String ipAddress, String fileName) {
		String command = "scp " + userName + "@" + ipAddress + ":" + this.hadoopDeployPath + "/"
				+ Util.HadoopConf.HADOOP_CONF_DIR + "/"
				+ fileName + " " + ToolParentPath + "/"
				+ Util.Tool.DEPLOY_TEMP_DIR + "/";
		String[] getCmd = { "/bin/bash", "-c", command };
		try {
			Process getP = Runtime.getRuntime().exec(getCmd);
			if (getP.waitFor() != 0) {
				throw new Exception("Fail");
			}
			File initFile = new File(ToolParentPath + "/"
					+ Util.Tool.DEPLOY_TEMP_DIR + "/"
					+ fileName);
			File sourceFile = new File(ToolParentPath + "/"
					+ Util.Tool.DEPLOY_TEMP_DIR + "/"
					+ fileName + ".tmp");
			initFile.renameTo(sourceFile);
			FileReader fr = new FileReader(sourceFile);
			BufferedReader br = new BufferedReader(fr, 65536);
			String read, content;
			while ((read = br.readLine()) != null) {
				content = Util.XML.filter(read, Util.XML.PROPERTY_NAME_START,
						Util.XML.PROPERTY_NAME_END);
				if (content != null) {
					Vector<String> row = new Vector<String>();
					row.add(content);
					read = br.readLine();
					content = Util.XML.filter(read,
							Util.XML.PROPERTY_VALUE_START,
							Util.XML.PROPERTY_VALUE_END);
					row.add(content);
					row.add(fileName);
					this.paramListDTM.addRow(row);
				}
			}

			br.close();
			fr.close();
			sourceFile.delete();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this.frame,
					"ERROR!\nFail to get " + fileName + " file at NameNode: " + masterName + "!");
			//e.printStackTrace();
		}
	}
	
	/**
	 * Clean up resources before quit the configuration window.
	 */
	private void clean() {
		
	}
	
	public void update() {
		int a = JOptionPane.showConfirmDialog(null,
				"Are you sure to update configuration info on every worker?",
				"Note", JOptionPane.YES_NO_OPTION);
		if (a != 0) {
			return;
		}
		
		SetHadoop sh = new SetHadoop(this.frame, ToolParentPath, this.hadoopDeployPath, this.paramListDTM,
				this.workerListDTM, this.opResultJTA);
		sh.start();
	}

	public void cancel() {
		clean();
		this.frame.dispose();
	}
}
