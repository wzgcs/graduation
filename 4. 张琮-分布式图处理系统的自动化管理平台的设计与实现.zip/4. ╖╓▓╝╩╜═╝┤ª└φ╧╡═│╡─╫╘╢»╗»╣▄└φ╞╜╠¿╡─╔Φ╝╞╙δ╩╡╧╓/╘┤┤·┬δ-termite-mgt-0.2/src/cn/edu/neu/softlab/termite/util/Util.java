package cn.edu.neu.softlab.termite.util;
import java.io.BufferedWriter;


public class Util {
	
	public static class Tool {
		public static String MASTER_NAME_HEADER = "two-master-name";
		public static String MASTER_SERVER_PORT_HEADER = "two-master-port";
		public static String LINUX_CHECK_FILE = "profile";
		public static String JDK_HOME_CHECK_HEADER = "JAVA_HOME=";
		public static String TERMITE_DEPLOY_PATH_HEADER = "TERMITE_HOME=";
		public static String HADOOP_DEPLOY_PATH_HEADER = "HADOOP_HOME=";
		
		public static String DEPLOY_CACHE_DIR = "cache";
		public static String DEPLOY_CACHE_File = "cache.info";
		public static String COMMANDS_CACHE_FILE = "commands.info";
		public static String COPY_REPLACE_VALUE = "destination";
		
		public static String DEPLOY_TEMP_DIR = "tmp";
		
		public static String COPYRIGHT_INFO = "2011-2014 Copyright(c). The Computer SoftWare and Theory Institute, Northeastern University";
		public static String ADDRESS = "Address: Information Science Museum 401";
		public static String EMAIL = "Email: wangzhigang1210@163.com";
		public static String VERSION_INFO = "v2.0";
	}
	
	public static class TermiteConf {
		public static String TERMITE_CONF_DIR = "conf";
		public static String TERMITE_CONF_ENV_FILE = "termite-env.sh";
		public static String TERMITE_CONF_SITE_FILE = "termite-site.xml";
		public static String TERMITE_CONF_WORKERS_FILE = "workers";
		public static String TERMITE_CONF_SITE_SKIP = "bsp.task.max";
	}
	
	public static class HadoopConf {
		public static String HADOOP_CONF_DIR = "conf";
		public static String HADOOP_CONF_ENV_FILE = "hadoop-env.sh";
		public static String HADOOP_CONF_CORE_FILE = "core-site.xml";
		public static String HADOOP_CONF_HDFS_FILE = "hdfs-site.xml";
		public static String HADOOP_CONF_MAPRED_FILE = "mapred-site.xml";
		public static String HADOOP_CONF_SLAVES_FILE = "slaves";
	}
	
	public static class XML {
		public static String VERSION_INFO = "<?xml version=\"1.0\"?>";
		public static String TYPE_INFO = "<?xml-stylesheet type=\"text/xsl\" href=\"configuration.xsl\"?>";
		public static String CONTENT_START = "<configuration>";
		public static String CONTENT_END = "</configuration>";
		public static String PROPERTY_START = "<property>";
		public static String PROPERTY_END = "</property>";
		public static String PROPERTY_NAME_START = "<name>";
		public static String PROPERTY_NAME_END = "</name>";
		public static String PROPERTY_VALUE_START = "<value>";
		public static String PROPERTY_VALUE_END = "</value>";
		
		public static String filter(String content, String startFlag, String endFlag) {
			String result = null;
			int start = -1, end = -1;
			start = content.indexOf(startFlag);
			end = content.indexOf(endFlag);
			
			if (start != -1 && end != -1) {
				result = content.substring(start + startFlag.length(), end);
			}
			
			return result;
		}
		
		public static void writeHeader(BufferedWriter bw) throws Exception {
			bw.write(VERSION_INFO); bw.newLine();
			bw.write(TYPE_INFO); bw.newLine();
			bw.write(CONTENT_START);
		}
		
		public static void writeEnd(BufferedWriter bw) throws Exception {
			bw.write(CONTENT_END);
		}
		
		public static void writeRecord(BufferedWriter bw, String name, String value) throws Exception {
			bw.newLine();
			bw.write(PROPERTY_START); bw.newLine();
			bw.write(PROPERTY_NAME_START + name + PROPERTY_NAME_END); bw.newLine();
			bw.write(PROPERTY_VALUE_START + value + PROPERTY_VALUE_END); bw.newLine();
			bw.write(PROPERTY_END);
		}
	}
	
	public static class Monitor {
		public static String MAX_PROGRESS = "MaxProgress: ";
		public static String MIN_PROGRESS = "MinProgress: ";
		public static String MAX_USED_MEM = "MaxUsedMem: ";
		public static String MIN_USED_MEM = "MinUsedMem: ";
		public static String JOB_START_TIME = "JobStartTime: ";
		public static String JOB_FINISH_TIME = "JobFinishTime: ";
		public static String JOB_USED_TIME = "JobUsedTime(m): ";
		public static String JOB_REMIAN_TIME = "JobRemainTime(m): ";
	}
}