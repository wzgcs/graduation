package cn.edu.neu.softlab.termite.deploy.cluster;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import cn.edu.neu.softlab.termite.util.Util;

public class RemoveWorker {
	
	String newUserName;
	String newIpAddress;
	String newHostName;
	String hadoopLocalPath;
	String hadoopDeployPath;
	String termiteLocalPath;
	String termiteDeployPath;
	
	public  RemoveWorker(String newUserName, String newIpAddress, String newHostName,
			String hadoopLocalPath, String hadoopDeployPath, String termiteLocalPath, String termiteDeployPath) {
		this.newUserName = newUserName;
		this.newIpAddress = newIpAddress;
		this.newHostName = newHostName;
		
		this.hadoopLocalPath = hadoopLocalPath;
		this.hadoopDeployPath = hadoopDeployPath;
		this.termiteLocalPath = termiteLocalPath;
		this.termiteDeployPath = termiteDeployPath;
	}
	
	public void closeDaemon() throws Exception {
		/*String command_stop_hdfs = ("ssh -l " + this.newUserName + " " + this.newIpAddress  + " " + "\"" 
				+ "$HADOOP_HOME/bin/hadoop-daemon.sh stop datenode" + "\"");*/
		String command_stop_termite = ("ssh -l " + this.newUserName + " " + this.newIpAddress  + " " + "\"" 
				+ "$TERMITE_HOME/bin/termite-daemon.sh stop worker" + "\"");
		//String cmd3[] = {"/bin/bash", "-c", command_stop_hdfs};
		String cmd4[] = {"/bin/bash", "-c", command_stop_termite};
		//Process pro_hadoop = Runtime.getRuntime().exec(cmd3);
		Process pro_termite  = Runtime.getRuntime().exec(cmd4);
		//pro_hadoop.waitFor();
		if (pro_termite.waitFor() != 0) {
			throw new Exception("Fail");
		}
	}
	
	public void changeWorkermanager(String rootPath, String hadoopIP, String hadoopUserName,
			String bcbspIP, String bcbspUserName) throws Exception {
		String command = null;
		String[] cmd = {"/bin/bash", "-c", command};
		Process p;
		
		// change Hadoop
		command = "scp " + hadoopUserName + "@" + hadoopIP + ":" + this.hadoopDeployPath + "/" + Util.HadoopConf.HADOOP_CONF_DIR + "/"
				+ Util.HadoopConf.HADOOP_CONF_SLAVES_FILE + " " + rootPath + "/"
				+ Util.Tool.DEPLOY_TEMP_DIR + "/";
		cmd[2] = command;
		p = Runtime.getRuntime().exec(cmd);
		if (p.waitFor() != 0) {
			throw new Exception("Fail");
		}
		
		File hadoopFile = new File(rootPath + "/" + Util.Tool.DEPLOY_TEMP_DIR, Util.HadoopConf.HADOOP_CONF_SLAVES_FILE);
		File hadoopFileRead = new File(rootPath + "/" + Util.Tool.DEPLOY_TEMP_DIR, Util.HadoopConf.HADOOP_CONF_SLAVES_FILE + ".tmp");
		File hadoopFileWrite = new File(rootPath + "/" + Util.Tool.DEPLOY_TEMP_DIR, Util.HadoopConf.HADOOP_CONF_SLAVES_FILE);
		hadoopFile.renameTo(hadoopFileRead);
		
		FileReader hadoopFR = new FileReader(hadoopFileRead);
		BufferedReader hadoopBR = new BufferedReader(hadoopFR);
		FileWriter hadoopFW = new FileWriter(hadoopFileWrite);
		BufferedWriter hadoopBW = new BufferedWriter(hadoopFW);
		
		String read = null;
		while ((read = hadoopBR.readLine()) != null) {
			if (read.equals(this.newHostName)) {
				continue;
			}
			hadoopBW.write(read);
			hadoopBW.newLine();
		}
		
		hadoopBR.close();
		hadoopFR.close();
		hadoopBW.close();
		hadoopFW.close();
		
		command = "scp " + hadoopFile.toString() + " " + hadoopUserName
				+ "@" + hadoopIP + ":" + this.hadoopDeployPath + "/" + Util.HadoopConf.HADOOP_CONF_DIR + "/";
		cmd[2] = command;
		p = Runtime.getRuntime().exec(cmd);
		if (p.waitFor() != 0) {
			throw new Exception("Fail");
		}
		hadoopFileRead.delete();
		hadoopFileWrite.delete();
		
		// change BCBSP
		command = "scp " + bcbspUserName + "@" + bcbspIP + ":" + this.termiteDeployPath + "/" + Util.TermiteConf.TERMITE_CONF_DIR + "/"
			+ Util.TermiteConf.TERMITE_CONF_WORKERS_FILE+ " " + rootPath + "/"
			+ Util.Tool.DEPLOY_TEMP_DIR + "/";
		cmd[2] = command;
		p = Runtime.getRuntime().exec(cmd);
		if (p.waitFor() != 0) {
			throw new Exception("Fail");
		}

		File bcbspFile = new File(rootPath + "/" + Util.Tool.DEPLOY_TEMP_DIR, Util.TermiteConf.TERMITE_CONF_WORKERS_FILE);
		File bcbspFileRead = new File(rootPath + "/" + Util.Tool.DEPLOY_TEMP_DIR, Util.TermiteConf.TERMITE_CONF_WORKERS_FILE + ".tmp");
		File bcbspFileWrite = new File(rootPath + "/" + Util.Tool.DEPLOY_TEMP_DIR, Util.TermiteConf.TERMITE_CONF_WORKERS_FILE);
		bcbspFile.renameTo(bcbspFileRead);
		
		FileReader bcbspFR = new FileReader(bcbspFileRead);
		BufferedReader bcbspBR = new BufferedReader(bcbspFR);
		FileWriter bcbspFW = new FileWriter(bcbspFileWrite);
		BufferedWriter bcbspBW = new BufferedWriter(bcbspFW);
		
		read = null;
		while ((read = bcbspBR.readLine()) != null) {
			if (read.equals(this.newHostName)) {
				continue;
			}
			bcbspBW.write(read);
			bcbspBW.newLine();
		}
		
		bcbspBR.close();
		bcbspFR.close();
		bcbspBW.close();
		bcbspFW.close();

		command = "scp " + bcbspFile.toString() + " " + bcbspUserName
				+ "@" + bcbspIP + ":" + this.termiteDeployPath + "/" + Util.TermiteConf.TERMITE_CONF_DIR + "/";
		cmd[2] = command;
		p = Runtime.getRuntime().exec(cmd);
		if (p.waitFor() != 0) {
			throw new Exception("Fail");
		}
		bcbspFileRead.delete();
		bcbspFileWrite.delete();
	}
}
