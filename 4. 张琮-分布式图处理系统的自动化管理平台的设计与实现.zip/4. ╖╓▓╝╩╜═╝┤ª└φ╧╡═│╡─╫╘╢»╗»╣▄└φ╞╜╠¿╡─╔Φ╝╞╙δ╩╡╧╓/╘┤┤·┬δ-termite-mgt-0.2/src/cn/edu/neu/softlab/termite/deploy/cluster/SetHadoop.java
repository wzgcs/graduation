package cn.edu.neu.softlab.termite.deploy.cluster;

import java.awt.Container;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import cn.edu.neu.softlab.termite.util.Util;

public class SetHadoop extends Thread {
	
	private static String ToolParentPath;
	private String hadoopDeployPath ;
	private DefaultTableModel workerListDTM;
	private DefaultTableModel paramListDTM;
	private JTextArea opResultJTA;
	
	private JFrame jf;
	private Container c;
	
	public SetHadoop(JFrame parentWin, String toolParentPath,
			String hadoopDeployPath, DefaultTableModel paramListDTM,
			DefaultTableModel workerListDTM, JTextArea opResultJTA) {
		ToolParentPath = toolParentPath;
		this.hadoopDeployPath = hadoopDeployPath;
		this.paramListDTM = paramListDTM;
		this.workerListDTM = workerListDTM;
		this.opResultJTA = opResultJTA;
		
		this.jf = new JFrame("Hadoop Configurations");
		this.jf.setBounds(parentWin.getX() + 150, parentWin.getY() + 350, 500, 100);
		this.c = jf.getContentPane();
		this.c.setLayout(null);
	}
	
	private void makeAndSendFile(String fileName, String userName, String ipAddress) throws Exception {
		File dstFile = new File(ToolParentPath + "/"
				 + Util.Tool.DEPLOY_TEMP_DIR + "/"
				 + fileName);
		FileWriter fw = new FileWriter(dstFile);
		BufferedWriter bw = new BufferedWriter(fw);
		
		Util.XML.writeHeader(bw);
		for (int i = 0; i < this.paramListDTM.getRowCount(); i++) {
			if (this.paramListDTM.getValueAt(i, 2).toString().equals(fileName)) {
				Util.XML.writeRecord(bw, this.paramListDTM.getValueAt(i, 0).toString(), this.paramListDTM.getValueAt(i, 1).toString());
			}
		}
		Util.XML.writeEnd(bw);
			
		bw.close();
		fw.close();
		String command = "scp " + dstFile.toString() + " " + userName
				+ "@" + ipAddress + ":" + this.hadoopDeployPath + "/" + Util.HadoopConf.HADOOP_CONF_DIR + "/";
		//System.out.println(command);
		String[] backCmd = {"/bin/bash","-c",command};
		Process backP = Runtime.getRuntime().exec(backCmd);
		if (backP.waitFor() != 0) {
			throw new Exception("Fail");
		}
		dstFile.delete();
	}
	
	@Override
	public void run() {
		JPanel jp = new JPanel();
		jp.setLayout(null);
		jp.setBounds(10, 0, 480, 75);
		
		JLabel tagJL = new JLabel("Set Hadoop configurations, please wait ...");
		tagJL.setBounds(0, 0, 480, 20);
		jp.add(tagJL);
		
		JProgressBar progressbar = new JProgressBar();
        progressbar.setOrientation(JProgressBar.HORIZONTAL);
        progressbar.setMinimum(0);
        progressbar.setMaximum(this.workerListDTM.getRowCount() - 1);
        progressbar.setValue(0);
        progressbar.setStringPainted(true);
        progressbar.setBorderPainted(true);
        progressbar.setBounds(0, 25, 480, 20);
        jp.add(progressbar);
        
        JLabel explain = new JLabel("begin to set hadoop configurations, 0/" + this.workerListDTM.getRowCount());
        explain.setBounds(0, 50, 480, 20);
        jp.add(explain);
        
        this.c.add(jp);
        this.jf.setVisible(true);
		
        int successCounter = 0, failCounter = 0;
		int index = 0, loop = this.workerListDTM.getRowCount();
		for (; index < loop; index++) {
			explain.setText("set hadoop configurations on " + this.workerListDTM.getValueAt(index, 0)
					+ ", " + (index + 1) + "/" + this.workerListDTM.getRowCount());
			try {
				makeAndSendFile(Util.HadoopConf.HADOOP_CONF_CORE_FILE, 
						this.workerListDTM.getValueAt(index, 2).toString(), this.workerListDTM.getValueAt(index, 1).toString());
				makeAndSendFile(Util.HadoopConf.HADOOP_CONF_HDFS_FILE, 
						this.workerListDTM.getValueAt(index, 2).toString(), this.workerListDTM.getValueAt(index, 1).toString());
				makeAndSendFile(Util.HadoopConf.HADOOP_CONF_MAPRED_FILE, 
						this.workerListDTM.getValueAt(index, 2).toString(), this.workerListDTM.getValueAt(index, 1).toString());
					
				File dstFile = new File(ToolParentPath + "/"
						+ Util.Tool.DEPLOY_TEMP_DIR + "/"
						+ Util.HadoopConf.HADOOP_CONF_ENV_FILE);
				FileWriter fw = new FileWriter(dstFile);
				fw.write("export JAVA_HOME=" + this.workerListDTM.getValueAt(index, 5));
				fw.close();
				String command = "scp " + dstFile.toString() + " " + this.workerListDTM.getValueAt(index, 2).toString()
						+ "@" + this.workerListDTM.getValueAt(index, 1) + ":" + this.hadoopDeployPath + "/" + Util.HadoopConf.HADOOP_CONF_DIR + "/";
				//System.out.println(command);
				String[] backCmd = {"/bin/bash","-c",command};
				Process backP = Runtime.getRuntime().exec(backCmd);
				if (backP.waitFor() != 0) {
					throw new Exception("Fail");
				}
				dstFile.delete();
				progressbar.setValue(index);
				this.opResultJTA.append("Set Hadoop configurations on " + this.workerListDTM.getValueAt(index, 1) + " successfully!\n");
				successCounter++;
			} catch (Exception e) {
				opResultJTA.append("Set Hadoop configurations on " + this.workerListDTM.getValueAt(index, 1) + " fail!\n");
				failCounter++;
			}
		}
		
		explain.setText("set hadoop configurations over" +  ", total:" + loop + ", success:" + successCounter + ", fail:" + failCounter);
	}
}
