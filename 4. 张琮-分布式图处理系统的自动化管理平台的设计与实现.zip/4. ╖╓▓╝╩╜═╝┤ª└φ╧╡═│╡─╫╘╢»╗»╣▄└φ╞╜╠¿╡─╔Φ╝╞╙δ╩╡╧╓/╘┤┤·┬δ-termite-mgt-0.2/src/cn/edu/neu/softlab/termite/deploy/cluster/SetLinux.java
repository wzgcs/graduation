package cn.edu.neu.softlab.termite.deploy.cluster;

import java.awt.Container;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import cn.edu.neu.softlab.termite.util.Util;

public class SetLinux extends Thread {
	
	private static String ToolParentPath;
	private String hadoopDeployPath ;
	private String termiteDeployPath;
	private DefaultTableModel workerListDTM;
	private JTextArea opResultJTA;
	
	private JFrame jf;
	private Container c;
	
	public SetLinux(JFrame parentWin, String toolParentPath,
			String hadoopDeployPath, String termiteDeployPath,
			DefaultTableModel workerListDTM, JTextArea opResultJTA) {
		ToolParentPath = toolParentPath;
		this.hadoopDeployPath = hadoopDeployPath;
		this.termiteDeployPath = termiteDeployPath;
		this.workerListDTM = workerListDTM;
		this.opResultJTA = opResultJTA;
		
		this.jf = new JFrame("Linux Configuration");
		this.jf.setBounds(parentWin.getX() + 150, parentWin.getY() + 350, 500, 100);
		this.c = jf.getContentPane();
		this.c.setLayout(null);
	}
	
	public void setLinuxProfile(String hostName, String ipAddress, String userName) throws Exception {
		String command = "scp " + userName + "@" + ipAddress + ":/etc/"
				+ Util.Tool.LINUX_CHECK_FILE + " " + ToolParentPath + "/"
				+ Util.Tool.DEPLOY_TEMP_DIR + "/";
		String[] getCmd = { "/bin/bash", "-c", command };
		Process getP = Runtime.getRuntime().exec(getCmd);
		if (getP.waitFor() != 0) {
			throw new Exception("Fail");
		}
		File initFile = new File(ToolParentPath + "/"
				+ Util.Tool.DEPLOY_TEMP_DIR + "/"
				+ Util.Tool.LINUX_CHECK_FILE);
		File sourceFile = new File(ToolParentPath + "/"
				+ Util.Tool.DEPLOY_TEMP_DIR + "/"
				+ Util.Tool.LINUX_CHECK_FILE + ".tmp");
		initFile.renameTo(sourceFile);
		FileReader fr = new FileReader(sourceFile);
		BufferedReader br = new BufferedReader(fr, 65536);
		File dstFile = new File(ToolParentPath + "/"
				+ Util.Tool.DEPLOY_TEMP_DIR + "/"
				+ Util.Tool.LINUX_CHECK_FILE);
		FileWriter fw = new FileWriter(dstFile);
		BufferedWriter bw = new BufferedWriter(fw);
		String read;
		while ((read = br.readLine()) != null) {
			int index = read.indexOf("TERMITE");
			if (index != -1) {
				continue;
			}
			index = read.indexOf("HADOOP");
			if (index != -1) {
				continue;
			}
			bw.write(read);
			bw.newLine();
		}
		
		bw.write("export " + Util.Tool.HADOOP_DEPLOY_PATH_HEADER + this.hadoopDeployPath);
		bw.newLine();
		bw.write("export HADOOP_CONF_DIR=" + this.hadoopDeployPath + "/conf");
		bw.newLine();
		bw.write("export PATH=$HADOOP_HOME/bin:$PATH");
		bw.newLine();
		
		bw.write("export " + Util.Tool.TERMITE_DEPLOY_PATH_HEADER + this.termiteDeployPath);
		bw.newLine();
		bw.write("export TERMITE_CONF_DIR=" + this.termiteDeployPath + "/conf");
		bw.newLine();
		bw.write("export PATH=$PATH:$TERMITE_HOME/bin");
		
		br.close();
		fr.close();
		bw.close();
		fw.close();
		sourceFile.delete();
		
		command = "scp " + dstFile.toString() + " "
				+ userName + "@" + ipAddress + ":/etc/";
		String[] backCmd = {"/bin/bash","-c",command};
		Process backP = Runtime.getRuntime().exec(backCmd);
		if (backP.waitFor() != 0) {
			throw new Exception("Fail");
		}
		dstFile.delete();
	}
	
	@Override
	public void run() {
		JPanel jp = new JPanel();
		jp.setLayout(null);
		jp.setBounds(10, 0, 480, 75);
		
		JLabel tagJL = new JLabel("Set Linux /etc/profile, please wait ...");
		tagJL.setBounds(0, 0, 480, 20);
		jp.add(tagJL);
		
		JProgressBar progressbar = new JProgressBar();
        progressbar.setOrientation(JProgressBar.HORIZONTAL);
        progressbar.setMinimum(0);
        progressbar.setMaximum(this.workerListDTM.getRowCount() - 1);
        progressbar.setValue(0);
        progressbar.setStringPainted(true);
        progressbar.setBorderPainted(true);
        progressbar.setBounds(0, 25, 480, 20);
        jp.add(progressbar);
        
        JLabel explain = new JLabel("begin to set linux /etc/profile, 0/" + this.workerListDTM.getRowCount());
        explain.setBounds(0, 50, 480, 20);
        jp.add(explain);
        
        this.c.add(jp);
        this.jf.setVisible(true);
		
		int successCounter = 0, failCounter = 0;
		int index = 0, loop = this.workerListDTM.getRowCount();
		for(; index < loop; index++) {
			explain.setText("set linux /etc/profile on " + this.workerListDTM.getValueAt(index, 0)
					+ ", " + (index + 1) + "/" + this.workerListDTM.getRowCount());
			try {
				setLinuxProfile(this.workerListDTM.getValueAt(index, 0).toString(),
						this.workerListDTM.getValueAt(index, 1).toString(), this.workerListDTM.getValueAt(index, 2).toString());
				progressbar.setValue(index);
				opResultJTA.append("Set Linux /etc/profile on " + this.workerListDTM.getValueAt(index, 1) + " successfully!\n");
				successCounter++;
			} catch (Exception e) {
				opResultJTA.append("Set Linux /etc/profile on " + this.workerListDTM.getValueAt(index, 1) + " fail!\n");
				failCounter++;
			}
		}
		
		explain.setText("set /etc/profile over" +  ", total:" + loop + ", success:" + successCounter + ", fail:" + failCounter);
	}
}
