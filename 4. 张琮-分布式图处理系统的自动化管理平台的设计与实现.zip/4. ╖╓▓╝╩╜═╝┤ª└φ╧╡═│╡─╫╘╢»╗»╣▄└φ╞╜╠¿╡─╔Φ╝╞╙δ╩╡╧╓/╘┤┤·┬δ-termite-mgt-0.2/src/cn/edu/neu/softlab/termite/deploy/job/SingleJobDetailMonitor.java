package cn.edu.neu.softlab.termite.deploy.job;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.apache.hadoop.ipc.RPC;
import org.apache.hadoop.net.NetUtils;
import org.apache.hama.HamaConfiguration;
import org.apache.hama.bsp.BSPJobID;
import org.apache.hama.bsp.JobStatus;
import org.apache.hama.bsp.TaskAttemptID;
import org.apache.hama.bsp.TaskStatus;
import org.apache.hama.ipc.JobSubmissionProtocol;

import cn.edu.neu.softlab.termite.util.Util;

public class SingleJobDetailMonitor extends Thread {
	
	private JFrame jf;
	private Container c;
	
	// The handler used to connect with Termite and JobStatus.
	private BSPJobID jobId;
	private JobSubmissionProtocol jobMonitorClient;
	private JobStatus jobStatus;
	private int taskNum = 0;
	private int currentSS = 0, totalSS = 0;
	private volatile boolean finishTag = false;
	
	// Variables relatived with job information.
	private JLabel jobIDJL;
	private JLabel taskNumJL;
	private JLabel currentSSJL, totalSSJL;
	private JLabel progressTagJL;
	private JProgressBar jobProgressJPB;
	private JPanel jobJP = new JPanel();
	
	// Variables relatived with task information.
	private JLabel[] taskWarnListJL;
	private JLabel[] taskIDListJL;
	private JLabel[] workerNameListJL;
	private JProgressBar[] taskProgressListJPB;
	private JLabel[] taskStatusListJL;
	private JLabel[] taskUsedMemListJL;
	private JPanel taskListJP = new JPanel();
	private JScrollPane taskListJSP = new JScrollPane(taskListJP);
	
	// Variable relatived with statistics data.
	private JLabel jobStartTime, jobFinishTime;
	private JLabel usedTime, remainTime;
	private JPanel statisticsJP = new JPanel();
	
	// Cache the progress of tasks in order to search 
	// the slow tasks and give the warn to the user.
	private static int[] ProgressCache;
	private static long[] ReportTime;
	private static volatile long UpdateInterval = 1000;
	private static volatile long WarnThreshold = 5000;
	private static JTextField UpdateIntervalJT = 
		new JTextField(Long.toString(UpdateInterval));
	private static JTextField WarnThresholdJT = 
		new JTextField(Long.toString(WarnThreshold));
	
	public class WindowAction implements WindowListener {
		
		@SuppressWarnings("deprecation")
		public void windowClosing(WindowEvent e) {
			finishTag = true;
			stop();
		}

		public void windowActivated(WindowEvent e) {};
		public void windowClosed(WindowEvent e) {};
		public void windowDeactivated(WindowEvent e) {};
		public void windowDeiconified(WindowEvent e) {};
		public void windowIconified(WindowEvent e) {};
		public void windowOpened(WindowEvent e) {};
	}
	
	@SuppressWarnings("deprecation")
	public SingleJobDetailMonitor(String jobId, String masterName, 
			String masterServerPort) {
		this.jf = new JFrame("Monitor for one Job in detail");
		this.jf.setResizable(false);
		this.jf.setBounds(300, 300, 700, 670);
		this.jf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.c = jf.getContentPane();
		this.c.setLayout(null);
		this.jobJP.setLayout(null);
		this.taskListJP.setLayout(null);
		this.statisticsJP.setLayout(null);
		
		try {
			createConnect(masterName, masterServerPort);
			this.jobId = new BSPJobID().forName(jobId);
			this.jobStatus = this.jobMonitorClient.getJobStatus(this.jobId);
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.jf, "ERROR! Fail to connect with " 
					+ masterName + ":" + masterServerPort);
			return;
		}
		
		this.taskNum = this.jobStatus.getTaskNum();
		this.currentSS = this.jobStatus.getSuperstepCounter();
		this.totalSS = this.jobStatus.getTotalSuperStep();
		
		// Set the job Panel
		this.jobJP.setBounds(10, 10, 680, 90);
		this.jobJP.setBorder(BorderFactory.createEtchedBorder());
		JLabel jobTag = new JLabel("Job Information");
		jobTag.setBounds(5, 5, 100, 20);
		this.jobJP.add(jobTag);
		
		this.jobIDJL = new JLabel("JobID: " + this.jobId.toString());
		this.jobIDJL.setBounds(5, 35, 210, 20);
		this.taskNumJL = new JLabel("TaskNumber: " + taskNum);
		this.taskNumJL.setBounds(225, 33, 120, 20);
		this.currentSSJL = new JLabel("CurrentSuperStep: " + currentSS);
		this.currentSSJL.setBounds(355, 35, 160, 20);
		this.totalSSJL = new JLabel("TotalSuperStep: " + totalSS);
		this.totalSSJL.setBounds(525, 35, 160, 20);
		this.jobJP.add(this.jobIDJL);
		this.jobJP.add(this.taskNumJL);
		this.jobJP.add(this.currentSSJL);
		this.jobJP.add(this.totalSSJL);
		
		this.progressTagJL = new JLabel("Loading");
		this.progressTagJL.setBounds(5, 60, 60, 20);
		this.jobProgressJPB = new JProgressBar();
		this.jobProgressJPB.setOrientation(JProgressBar.HORIZONTAL);
		this.jobProgressJPB.setStringPainted(true);
		this.jobProgressJPB.setBorderPainted(true);
		this.jobProgressJPB.setBounds(75, 60, 595, 20);
		this.jobProgressJPB.setMinimum(0);
		this.jobProgressJPB.setMaximum(100);
		this.jobJP.add(this.progressTagJL);
		this.jobJP.add(this.jobProgressJPB);
		
		// Set the tasks Panel and JSCrollPane
		this.taskListJSP.setBounds(10, 110, 680, 405);
		this.taskListJSP.setBorder(BorderFactory.createEtchedBorder());
		this.taskListJP.setPreferredSize(new Dimension(650, taskNum * 20 
				+ (taskNum - 1) * 5 + 65));
		this.taskListJP.setBorder(BorderFactory.createEtchedBorder());
		JLabel taskTag = new JLabel("Tasks Information");
		taskTag.setBounds(5, 5, 150, 20);
		this.taskListJP.add(taskTag);
		
		int base = 470;
		JLabel normalTagJL = new JLabel();
		JLabel normalTextJL = new JLabel("Normal");
		normalTagJL.setOpaque(true);
		normalTagJL.setBackground(Color.GREEN);
		normalTagJL.setBounds(base, 10, 10, 10);
		normalTextJL.setBounds(base + 15, 5, 50, 20);
		JLabel warnTagJL = new JLabel();
		JLabel warnTextJL = new JLabel("Warn");
		warnTagJL.setOpaque(true);
		warnTagJL.setBackground(Color.YELLOW);
		warnTagJL.setBounds(base + 75, 10, 10, 10);
		warnTextJL.setBounds(base + 90, 5, 40, 20);
		JLabel failTagJL = new JLabel();
		JLabel failTextJL = new JLabel("Fail");
		failTagJL.setOpaque(true);
		failTagJL.setBackground(Color.RED);
		failTagJL.setBounds(base + 140, 10, 10, 10);
		failTextJL.setBounds(base + 155, 5, 50, 20);
		this.taskListJP.add(normalTagJL);
		this.taskListJP.add(normalTextJL);
		this.taskListJP.add(warnTagJL);
		this.taskListJP.add(warnTextJL);
		this.taskListJP.add(failTagJL);
		this.taskListJP.add(failTextJL);
		
		JLabel taskWarnTagJL = new JLabel("WarnTag", SwingConstants.CENTER);
		taskWarnTagJL.setBounds(5, 35, 60, 20);
		JLabel taskIDTagJL = new JLabel("TaskID");
		taskIDTagJL.setBounds(65, 35, 50, 20);
		JLabel workerNameTagJL = new JLabel("WorkerName");
		workerNameTagJL.setBounds(120, 35, 100, 20);
		JLabel taskProgressTagJL = new JLabel("TaskProgress", SwingConstants.CENTER);
		taskProgressTagJL.setBounds(225, 35, 240, 20);
		JLabel taskStatusTagJL = new JLabel("TaskStatus");
		taskStatusTagJL.setBounds(470, 35, 80, 20);
		JLabel taskMemTagJL = new JLabel("TaskMemory");
		taskMemTagJL.setBounds(555, 35, 100, 20);
		this.taskListJP.add(taskWarnTagJL);
		this.taskListJP.add(taskIDTagJL);
		this.taskListJP.add(workerNameTagJL);
		this.taskListJP.add(taskProgressTagJL);
		this.taskListJP.add(taskStatusTagJL);
		this.taskListJP.add(taskMemTagJL);
		
		int height = 60;
		this.taskWarnListJL = new JLabel[taskNum];
		this.taskIDListJL = new JLabel[taskNum];
		this.workerNameListJL = new JLabel[taskNum];
		this.taskProgressListJPB = new JProgressBar[taskNum];
		this.taskStatusListJL = new JLabel[taskNum];
		this.taskUsedMemListJL = new JLabel[taskNum];
		for (int i = 0; i < taskNum; i++) {
			this.taskWarnListJL[i] = new JLabel();
			this.taskWarnListJL[i].setOpaque(true);
			this.taskWarnListJL[i].setBackground(Color.GREEN);
			this.taskWarnListJL[i].setBounds(25, height + 5, 10, 10);
			
			this.taskIDListJL[i] = new JLabel("null");//taskID.substring(26, 32)
			this.taskIDListJL[i].setBounds(65, height, 50, 20);
			
			this.workerNameListJL[i] = new JLabel("null");// "hadoop01"
			this.workerNameListJL[i].setBounds(120, height, 100, 20);
			
			this.taskProgressListJPB[i] = new JProgressBar();
			this.taskProgressListJPB[i].setOrientation(JProgressBar.HORIZONTAL);
			this.taskProgressListJPB[i].setStringPainted(true);
			this.taskProgressListJPB[i].setBorderPainted(true);
			this.taskProgressListJPB[i].setMinimum(0);
			this.taskProgressListJPB[i].setMaximum(100);// setValue
			this.taskProgressListJPB[i].setBounds(225, height, 240, 20);
			
			this.taskStatusListJL[i] = new JLabel("UNANSSIGNED");// "RUNNING"
			this.taskStatusListJL[i].setBounds(470, height, 80, 20);
			
			this.taskUsedMemListJL[i] = new JLabel("null");// "1024M/2048M"
			this.taskUsedMemListJL[i].setBounds(555, height, 100, 20);
			
			this.taskListJP.add(this.taskWarnListJL[i]);
			this.taskListJP.add(this.taskIDListJL[i]);
			this.taskListJP.add(this.workerNameListJL[i]);
			this.taskListJP.add(this.taskProgressListJPB[i]);
			this.taskListJP.add(this.taskStatusListJL[i]);
			this.taskListJP.add(this.taskUsedMemListJL[i]);
			
			height += 25;
		}
		
		// Set the panel of statistics data
		this.statisticsJP.setBounds(10, 525, 680, 110);
		this.statisticsJP.setBorder(BorderFactory.createEtchedBorder());
		JLabel statisticsTag = new JLabel("Statistics Information");
		statisticsTag.setBounds(5, 5, 200, 20);
		this.statisticsJP.add(statisticsTag);
		
		JLabel uiTagJL = new JLabel("UpdateInterval(ms)");
		uiTagJL.setBounds(5, 35, 150, 20);
		UpdateIntervalJT.setBounds(155, 35, 150, 20);
		JLabel wtTagJL = new JLabel("WarnThreshold(ms)");
		wtTagJL.setBounds(320, 35, 150, 20);
		WarnThresholdJT.setBounds(470, 35, 150, 20);
		this.statisticsJP.add(uiTagJL); this.statisticsJP.add(UpdateIntervalJT);
		this.statisticsJP.add(wtTagJL); this.statisticsJP.add(WarnThresholdJT);
		
		this.jobStartTime = new JLabel(Util.Monitor.JOB_START_TIME + "null");
		this.jobFinishTime = new JLabel(Util.Monitor.JOB_FINISH_TIME + "null");
		this.jobStartTime.setBounds(5, 60, 300, 20);
		this.jobFinishTime.setBounds(320, 60, 300, 20);
		this.statisticsJP.add(this.jobStartTime);
		this.statisticsJP.add(this.jobFinishTime);
		
		this.usedTime = new JLabel(Util.Monitor.JOB_USED_TIME + "0");
		this.remainTime = new JLabel(Util.Monitor.JOB_REMIAN_TIME + "INF");
		this.usedTime.setBounds(5, 85, 300, 20);
		this.remainTime.setBounds(320, 85, 300, 20);
		this.statisticsJP.add(this.usedTime);
		this.statisticsJP.add(this.remainTime);
		
		this.c.add(this.jobJP);
		this.c.add(this.taskListJSP);
		this.c.add(this.statisticsJP);
		this.jf.setVisible(true);
		
		// Initialize the cache of progress.
		ProgressCache = new int[taskNum];
		ReportTime = new long[taskNum];
		long currentTime = this.jobStatus.getCurrentTime();
		for (int i = 0; i < taskNum; i++) {
			ProgressCache[i] = 0;
			ReportTime[i] = currentTime;
		}
	}

	private void createConnect(String name, String port) throws Exception {
		HamaConfiguration conf = new HamaConfiguration();
		this.jobMonitorClient = (JobSubmissionProtocol) RPC.getProxy(
		        JobSubmissionProtocol.class, JobSubmissionProtocol.versionID,
		        NetUtils.createSocketAddr(name, Integer.valueOf(port)), conf,
		        NetUtils.getSocketFactory(conf, JobSubmissionProtocol.class));
	}
	
	@SuppressWarnings("deprecation")
	private void update() throws Exception {
		this.jobStatus = this.jobMonitorClient.getJobStatus(this.jobId);
		
		this.currentSS = this.jobStatus.getSuperstepCounter();
		this.currentSSJL.setText("CurrentSuperStep: " + this.currentSS);
		
		if (this.jobStartTime.getText().toString().endsWith("null") 
				&& this.jobStatus.getStartTime() != 0) {
			this.jobStartTime.setText(Util.Monitor.JOB_START_TIME + 
					new Date(this.jobStatus.getStartTime()).toLocaleString());
		}
		
		switch(this.jobStatus.getRunState()) {
		case JobStatus.PREP: break;
		case JobStatus.LOAD: break;
		case JobStatus.RUNNING: break;
		case JobStatus.SAVE: break;
		case JobStatus.SUCCEEDED: break;
		case JobStatus.FAILED: break;
		case JobStatus.KILLED: break;
		}
		
		if (this.jobStatus.getRunState() == JobStatus.SUCCEEDED 
				|| this.jobStatus.getRunState() == JobStatus.FAILED
				|| this.jobStatus.getRunState() == JobStatus.KILLED) {
			this.jobFinishTime.setText(Util.Monitor.JOB_FINISH_TIME + 
					new Date(this.jobStatus.getFinishTime()).toLocaleString());
			this.finishTag = true;
		}
		
		HashMap<TaskAttemptID, TaskStatus> taskStatuses = 
			this.jobStatus.getTaskStatuses();
		if (taskStatuses.size() != this.taskNum) {
			return;
		}
		
		long currentTime = this.jobStatus.getCurrentTime();
		int minProgress = 100;
		for (Entry<TaskAttemptID, TaskStatus> entry: taskStatuses.entrySet()) {
			String ID = entry.getKey().toString().substring(26, 32);
			TaskStatus ts = entry.getValue();
			int index = Integer.valueOf(ID);
			this.taskIDListJL[index].setText(ID);
			
			String initName = ts.getGroomServer();
			int begin = initName.indexOf('_');
			String firstName = initName.substring(begin + 1);
			int end = firstName.indexOf('_');
			String name = firstName.substring(0, end);
			this.workerNameListJL[index].setText(name);
			int progress = (int)Math.ceil(ts.getProgress() * 100);
			
			if (ts.getRunState() != TaskStatus.State.KILLED 
					&& ts.getRunState() != TaskStatus.State.FAILED
					&& this.finishTag 
					&& this.jobStatus.getRunState() == JobStatus.SUCCEEDED) {
				progress = 100;
				ts.setRunState(TaskStatus.State.SUCCEEDED);
			}
			
			if (ts.getRunState() == TaskStatus.State.FAILED) {
				this.taskWarnListJL[index].setBackground(Color.RED);
			}
			if (ProgressCache[index] == progress) {
				if ((currentTime - ReportTime[index]) > WarnThreshold 
						&& progress != 100) {
					this.taskWarnListJL[index].setBackground(Color.YELLOW);
				}
			} else {
				ProgressCache[index] = progress;
				ReportTime[index] = currentTime;
				this.taskWarnListJL[index].setBackground(Color.GREEN);
			}
			
			this.taskProgressListJPB[index].setValue(progress);
			this.taskStatusListJL[index].setText(ts.getRunState().toString());
			this.taskUsedMemListJL[index].setText((int)ts.getUsedMemory() 
					+ "M/" + (int)ts.getTotalMemory() + "M");
			
			if (progress < minProgress) {
				minProgress = progress;
			}
		}
		
		if (this.currentSS == 0) {
			this.progressTagJL.setText("Loading");
			this.jobProgressJPB.setValue(minProgress);
		} else {
			this.progressTagJL.setText("Running");
			float totalProgress = ((this.currentSS - 1 
					+ (float)minProgress / 100) / this.totalSS) * 100;
			this.jobProgressJPB.setValue((int)totalProgress);
		}
		
		long usedTime = (currentTime - this.jobStatus.getStartTime()) / 1000;
		this.usedTime.setText(Util.Monitor.JOB_USED_TIME + usedTime);
		if (this.currentSS > 1) {
			float remainTime = (usedTime / (this.currentSS - 1 + (float)minProgress / 100)) 
					* (this.totalSS - this.currentSS + (1 - (float)minProgress / 100));
			this.remainTime.setText(Util.Monitor.JOB_REMIAN_TIME + (int)remainTime);
		}
		
		if (this.finishTag) {
			this.progressTagJL.setText("Finished");
			this.usedTime.setText(Util.Monitor.JOB_USED_TIME 
					+ (int)this.jobStatus.getRunCostTime());
			this.remainTime.setText(Util.Monitor.JOB_REMIAN_TIME + "0");
			
			if (this.jobStatus.getRunState() == JobStatus.SUCCEEDED) {
				this.jobProgressJPB.setValue(100);
			} else {
				this.jobProgressJPB.setValue(0);
			}
			
			JOptionPane.showMessageDialog(this.jf, "Job is finished: " 
					+ JobStatus.State.values()[this.jobStatus.getRunState() - 1]);
		}
	}
	
	@Override
	public void run() {
		while (!this.finishTag) {
			try {
				UpdateInterval = Long.valueOf(UpdateIntervalJT.getText().toString());
				WarnThreshold = Long.valueOf(WarnThresholdJT.getText().toString());
				update();
				Thread.sleep(UpdateInterval);
			} catch (Exception e) {
				e.printStackTrace();
				this.progressTagJL.setText("Finished");
				JOptionPane.showMessageDialog(this.jf, "ERROR! Fail to update status!");
				break;
			}
		}
	}
}
