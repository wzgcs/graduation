java -Djava.ext.dirs=./lib -jar termite-mgt-0.2.jar
